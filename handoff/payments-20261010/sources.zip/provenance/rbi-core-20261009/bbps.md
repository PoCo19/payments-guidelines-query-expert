# Master Direction – Reserve Bank of India (Bharat Bill Payment System) Directions, 2024

RBI/DPSS/2023-24/111 
CO.DPSS.POLC.No.S1114/02-27-020/2023-2024

February 29, 2024

The Chairman / Managing Director / Chief Executive
All Scheduled Commercial Banks including RRBs / 
Urban Cooperative Banks / State Cooperative Banks / District Central Cooperative Banks / 
NPCI Bharat BillPay Limited / Non-bank Payment System Participants

Dear Sir / Madam,

## Master Direction – Reserve Bank of India (Bharat Bill Payment System) Directions, 2024

The current regulations covering Bharat Bill Payment System (BBPS) ([RBI Circular DPSS.CO.PD.No.940/02.27.020/2014-15 dated November 28, 2014](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=9368&Mode=0)) provide for a tiered structure with (a) NPCI Bharat Bill Pay Ltd (NBBL) as a Central Unit (BBPCU) (b) Bharat Bill Payment Operating Units (BBPOUs) and (c) Agent network/s of the BBPOUs.

2. In view of significant developments in the payments landscape, a need was felt to review and update these regulations. Accordingly, as announced in [Statement on Developmental and Regulatory Policies dated June 08, 2023](https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=55815), it has been decided to put in place a revised regulatory framework - Bharat Bill Payment Systems Directions, 2024, as [annexed](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12616#ANN1) hereto.

3. These Directions seek to streamline the process of bill payments, enable greater participation, and enhance customer protection among other changes.

4. These Directions shall be applicable from April 01, 2024 and shall supersede the regulations cited in para 1. This is issued under Section 18 read with Section 10(2) of the Payment and Settlement Systems (PSS) Act, 2007 (Act 51 of 2007).

Yours faithfully,

(Gunveer Singh)
Chief General Manager-in-Charge

---

CO.DPSS.POLC.No.S1114/02-27-020/2023-2024 dated February 29, 2024

## Annex

## Master Direction – Reserve Bank of India (Bharat Bill Payment System) Directions, 2024

In exercise of the powers conferred under Section 18 read with Section 10(2) of the Payment and Settlement Systems Act, 2007 (PSS Act), the Reserve Bank of India being satisfied that it is necessary and expedient in the public interest to do so, hereby, issues the Directions hereinafter specified.

## 1. Short Title and Commencement

- These Directions shall be called the Reserve Bank of India (Bharat Bill Payment System) Directions, 2024.

- These Directions shall be applicable from April 01, 2024.

## 2. Applicability

The provisions of these Directions shall apply to:

- NPCI Bharat Bill Pay Limited (NBBL - a wholly owned subsidiary of National Payments Corporation of India); and

- All Bharat Bill Payment Operating Units (BBPOUs).

## 3. Authorisation requirement

- NBBL is the entity authorised as the Payment System Provider for Bharat Bill Payment System (BBPS).

- Any entity, other than a biller, operating a system for payment of bills outside the scope of BBPS is a ‘payment system’ under Section 2(1)(i) of PSS Act 2007 and will require authorisation as per Chapter III of the Act to undertake the activity.

## 4. Definitions

In these Directions, unless the context otherwise requires, the terms herein shall bear the meanings assigned to them below:

a. Agent Institution: An entity, certified by NBBL, which provides customer interface (physical / digital) for bill payments.

b. Bharat Bill Pay Central Unit (BBPCU): BBPCU is the entity which operates BBPS; sets operational, technical and business standards, and also undertakes clearing and settlement functions. NPCI Bharat BillPay Ltd. (NBBL) is the authorised BBPCU.

c. Bharat Bill Payment Operating Unit (BBPOUs): BBPOUs are the System Participants in BBPS. A BBPOU may function either as a Biller Operating Unit or a Customer Operating Unit or both.

- Biller Operating Unit (BOU) is an entity which onboards biller(s), either directly or through biller aggregator(s), on to the BBPS platform for collection of its bills.

- Customer Operating Unit (COU) is an entity which provides its customers with an interface (physical / digital) to pay bills, either directly or through agent institution(s).

d. Bharat Bill Payment System (BBPS): BBPS is an integrated bill payment platform which enables payment / collection of bills through multiple channels (Mobile Apps, Mobile Banking, Physical Agents, Bank branches, etc.) using various payment modes (UPI, Internet Banking, Cards, Cash, Prepaid Payment Instruments, etc.). The transactions facilitated through this platform will require the bill to be fetched before payment initiation. In case of transactions involving payments for prepaid services, the customer relationship with the biller will be validated through the platform.

e. Bill: Bill means any notice for payment raised by a biller for recurring or non-recurring payments. Bill also includes notice or advice for recharge of prepaid services.

f. Biller: An entity (including Central and State Government Department / Public Sector Undertaking / individuals) which is connected to BBPS through a BOU (either directly or through a biller aggregator) for collection of bill payments.

g. Biller Aggregator: An entity which aggregates billers for the purpose of enabling them to connect to a BOU.

h. Sponsor bank: A Scheduled Commercial Bank which facilitates settlement of non-bank BBPOUs with NBBL.

i. Technology Service Providers (TSP): Entities certified by NBBL to provide technology services and solutions to billers / BBPOUs / Agent Institutions to integrate with BBPS.

## 5. Participants in BBPS

a. Bharat Bill Pay Central Unit (BBPCU): NBBL as the BBPCU, provides a platform connecting customers and billers, through COUs and BOUs, respectively. NBBL also undertakes clearing and settlement activities for transactions routed through the BBPCU.

b. Bharat Bill Payment Operating Units (BBPOUs): Banks (All Scheduled Commercial Banks including RRBs / Urban Cooperative Banks / State Cooperative Banks / District Central Cooperative Banks), non-bank Payment Aggregators (PAs) [[1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12616#FN1)]  and other existing entities authorised as BBPOUs can participate in BBPS as Operating Units. Banks and non-bank PAs, intending to operate as BBPOUs, will not require a separate authorisation. They shall intimate DPSS, RBI, Central Office before commencing operations.

## 6. Roles and Responsibilities

The indicative roles and responsibilities of the system operator and system participants are as below:

## a. Bharat Bill Pay Central Unit (BBPCU)

- Setting the rules and regulations governing participation criteria and system operations;

- Setting the technical standards for participation in the system;

- Providing guaranteed settlement of all transactions routed through NBBL;

- Ensuring that all transactions have BBPS reference number from the payment initiation stage;

- Ensuring no funds in the system flow through any TSP; and

- Providing a framework for redressal of consumer disputes.

## b. Biller Operating Unit (BOU)

- Onboarding billers to BBPS;

- Ensuring compliance to due diligence requirements in respect of onboarding of merchants prescribed in [Guidelines on Regulation of Payment Aggregators and Payment Gateways dated March 17, 2020](https://rbi.org.in/Scripts/NotificationUser.aspx?Id=11822&Mode=0), as updated from time to time;

- Ensuring compliance to additional due diligence requirements which may be prescribed by NBBL for specific biller categories; and

- Ensuring due diligence of the billers onboarded through biller aggregators.

## c. Customer Operating Unit (COU)

- Providing digital / physical interface to their customers, directly or through agent institutions;

- Ensuring customers (including customers of their agent institutions) have access to all billers onboarded on BBPS;

- Providing a system for raising disputes; and

- Taking responsibility for the activities of its agent institutions, for which they have entered into agreement with the COU.

## 7. Escrow Account Operations

i. A non-bank BBPOU shall open an escrow account with a Scheduled Commercial Bank exclusively for BBPS transactions.

ii. Non-bank BBPOU operates as Payment Aggregator (PA) when it collects funds from its customers or settles funds with the billers onboarded by it. For the purpose of maintenance of escrow account, payment system operated by BBPOU shall be deemed to be ‘designated payment system’ under Section 23A of the PSS Act, 2007 (as amended from time to time).

iii. Eligible credits and debits in the escrow account of a COU are as follows:

- Credit of funds collected from the customers

- Debit towards settlement of BBPS transactions

- Credit / debit of failed / disputed transactions

- Recovery of charges / commissions pertaining to bill payment transactions

iv. Eligible credits and debits in the escrow account of a BOU are as follows:

- Debit of funds due to the billers

- Credit towards settlement of BBPS transactions

- Credit / debit of failed / disputed transactions

- Recovery of charges / commissions pertaining to bill payment transactions

v. All other instructions applicable on escrow accounts as provided in [Guidelines on Regulation of Payment Aggregators and Payment Gateways dated March 17, 2020](https://rbi.org.in/Scripts/NotificationUser.aspx?Id=11822&Mode=0) (as updated from time to time) shall be applicable for BBPS Escrow Account.

## 8. Complaint Management and Grievance Redressal

i. NBBL shall put in place a dispute resolution framework for centralised end-to-end complaint management in compliance with RBI’s guidelines on [Online Dispute Resolution (ODR) System for Digital Payments dated August 06, 2020](https://www.rbi.org.in/scripts/FS_Notification.aspx?Id=11946&fn=9&Mode=0), as updated from time to time.

ii. All participating COUs and BOUs shall be integrated to the centralised system and enable the customers and billers to raise and resolve disputes in accordance with the dispute resolution framework of NBBL. BBPS reference number generated while initiating the transaction shall be used for this purpose.

iii. COUs and BOUs shall ensure that failed transactions are dealt with in accordance with the timelines prescribed in RBI’s circular on [Harmonisation of Turn Around Time (TAT) and customer compensation for failed transactions using authorised Payment Systems dated September 20, 2019](https://www.rbi.org.in/scripts/FS_Notification.aspx?Id=11693&fn=9&Mode=0), as updated from time to time.

## 9. Supersession of earlier BBPS related guidelines/circulars

Following guidelines and circulars issued in connection with BBPS have been superseded by these Directions:

| S.No. | Circular No. | Date | Subject |
| --- | --- | --- | --- |
| 1. | [DPSS.CO.PD.No.940/02.27.020/2014-2015](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=9368&Mode=0) | November 28, 2014 | Implementation of Bharat Bill Payment System - Guidelines (Updated as on May 26, 2022) |
| 2. | [DPSS.CO.PD.No.605/02.27.020/2019-20](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11686&Mode=0) | September 16, 2019 | Bharat Bill Payment System - Expansion of biller categories |
| 3. | [CO.DPSS.POLC.No.S-188/02-27-020/2021-2022](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12113&Mode=0) | June 14, 2021 | Bharat Bill Payment System – Addition of Biller Category |
| 4. | [CO.DPSS.POLC.No.S-253/02-27-020/2022-23](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12325&Mode=0) | May 26, 2022 | Bharat Bill Payment System – Amendment to guidelines |

---

[1]  Entities authorised to operate as Payment Aggregator under PSS Act, 2007 (will include existing PAs which have been granted in-principle authorisation)
