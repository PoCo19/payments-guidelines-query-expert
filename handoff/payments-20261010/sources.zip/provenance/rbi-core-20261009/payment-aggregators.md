# Master Direction on Regulation of Payment Aggregator (PA)

RBI/DPSS/2025-26/141
CO.DPSS.POLC.No.S-633/02-14-008/2025-26

September 15, 2025

All Payment System Providers and Payment System Participants /
All Authorised Dealer banks /
All Scheduled Commercial Banks

Madam / Dear Sir,

## Master Direction on Regulation of Payment Aggregator (PA)

The Reserve Bank of India had issued the ‘Guidelines on Regulation of Payment Aggregators and Payment Gateways’ vide [circular DPSS.CO.PD.No.1810/02.14.008/2019-20 dated March 17, 2020](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11822&Mode=0) and [CO.DPSS.POLC.No.S33/02-14-008/2020-2021 dated March 31, 2021](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12050&Mode=0) for regulation of entities that were engaged in online payment aggregation. Further, vide [circular CO.DPSS.POLC.No.S-786/02-14-008/2023-24 dated October 31, 2023](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12561&Mode=0), directions were issued on ‘Regulation of Payment Aggregator – Cross Border (PA - Cross Border)’.

2. Subsequently on [April 16, 2024](https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=57713), Reserve Bank of India, placed on its website, for public comments, the following draft directions on regulation of PA:

- ‘[New draft directions on regulation of Payment Aggregators – Physical Point of Sale](https://www.rbi.org.in/Scripts/bs_viewcontent.aspx?Id=4418)’, and

- ‘[Amendments to the existing directions on Payment Aggregators](https://www.rbi.org.in/Scripts/bs_viewcontent.aspx?Id=4419)’.

3. On a review of the inputs received and in line with RBI’s endeavour to further rationalise the regulations, this comprehensive [Master Direction](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#MD) is issued under Section 18 read with Section 10 (2) of the Payment and Settlement Systems Act, 2007, and Section 10 (4) and Section 11 (1) of the Foreign Exchange Management Act (FEMA), 1999 for regulation of various categories of PA.

Yours faithfully,

(Gunveer Singh)
Chief General Manager-in-Charge

Encl.: As above

---

## Master Direction on Regulation of Payment Aggregators

Table of Contents

[Chapter I: Preliminary](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#CP1)

[1. Short Title and Commencement](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#1)

[2. Effective Date](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#2)

[3. Applicability](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#3)

[4. Definitions](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#4)

[Chapter II: Authorisation and Capital Requirements](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#CP2)

[5. Authorisation for PA Business](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#5)

[6. Capital Requirements](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#6)

[Chapter III: Conduct of PA business](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#CP3)

[7. Governance](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#7)

[8. Dispute Management Framework](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#8)

[9. Security, Fraud Prevention and Risk Management Framework](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#9)

[10. General Directions](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#10)

[11. Specific Directions applicable to PA – CB](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#11)

[12. Reports](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#12)

[Chapter IV: KYC and due diligence](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#CP4)

[13. Due Diligence for PA](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#13)

[14. Responsibilities of Acquiring Bank](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#14)

[15. Due Diligence through Assisted Mode](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#15)

[Chapter V: Settlement of Funds and Escrow Accounts](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#CP5)

[16. Escrow Accounts for PA](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#16)

[17. Core Portion of Escrow Accounts](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#17)

[18. General Directions on Escrow Account of PA](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#18)

[Chapter VI: Repeal and Savings](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#CP6)

In exercise of the powers conferred by Section 18 read with Section 10(2) of the Payment and Settlement Systems Act, 2007 (51 of 2007), and Section 10 (4) and Section 11 (1) of the Foreign Exchange Management Act (FEMA), 1999 (42 of 1999), the Reserve Bank of India, being satisfied that it is necessary and expedient in the public interest so to do, hereby, issues the Directions hereinafter specified.

## Chapter I

## Preliminary

## 1. Short Title and Commencement

a. These Directions shall be called the Reserve Bank of India (Regulation of Payment Aggregators) Directions, 2025.

## 2. Effective Date

a. These Directions shall be effective immediately unless indicated otherwise for any specific provision herein.

## 3. Applicability

a. These Directions shall apply to all bank and non-bank entities undertaking the business of Payment Aggregator (PA) as defined herein. These Directions shall also apply to all Authorised Dealer banks as well as Scheduled Commercial Banks which engage with entities undertaking PA business, to the extent hereinafter specified.

## 4. Definitions

a. Cash-on-delivery transaction: A merchant transaction wherein banknotes or currency notes, being legal tender in India, is offered or tendered, for and at the time of, delivery of goods and / or service(s).

b. Contact Point Verification (CPV): Physical verification of the address or place of business of the merchant.

c. E-commerce: Buying and selling of goods and services, including digital products, conducted over digital and electronic network.

Explanation: For the purposes of this definition, the term ‘digital & electronic network’ shall include network of computers, television channels and any other internet application used in automated manner such as web pages, extranets, mobiles, etc.

d. Inward transaction: Transaction involving the inflow of foreign exchange.

e. Marketplace: An e-commerce entity which provides an information technology platform on a digital or electronic network to facilitate transactions between buyer(s) and seller(s).

f. Merchant: An entity or a marketplace that sells goods, provides services, or offers investment products, and includes exporters and overseas sellers.

g. Outward transaction: Transaction involving the outflow of foreign exchange.

h. Payment channel: The method or manner through which payment instruction is initiated and processed in a payment system.

i. Payment Aggregator (PA): An entity that facilitates aggregation of payments made by customers to the merchants through one or more payment channels through the merchant’s interface (physical / virtual) for purchase of goods, services or investment products, and subsequently settles the collected funds to such merchants. PA is categorised as below:

i. PA – Physical (PA – P): PA that facilitates transaction(s) where both the acceptance device and payment instrument are physically present in close proximity while making the transaction.

ii. PA – Cross Border (PA – CB): PA that facilitates aggregation of cross-border payments for current account transactions, that are not prohibited under FEMA, for its onboarded merchants through e-commerce mode. There are two sub-categories of PA-CB:

- PA-CB facilitating inward transaction

- PA-CB facilitating outward transaction

Note: (1) A non-bank entity authorised as AD Category-II, and facilitating current account transactions not prohibited under FEMA (other than purchase or sale of goods or service), shall not fall within the purview of PA – CB business.

(2) A card transaction, where the foreign exchange settlement is facilitated by a card network and the aggregator receives the payment in local currency, is not part of PA – CB activity.

iii. PA – Online (PA – O): PA that facilitates transaction(s) where the acceptance device and payment instrument are not present in close proximity while making the transaction.

j. Payment Gateway (PG): An entity that provides technology infrastructure to route and facilitate processing of a payment transaction without any involvement in handling of funds.

k. Central KYC Records Registry (CKYCR), Officially Valid Document (OVD), equivalent e-document, digital KYC, and Video-based Customer Identification Procedure (V-CIP) shall have the same meanings as defined in [RBI Master Direction DBR.AML.BC.No.81/14.01.001/2015-16 dated February 25, 2016](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=11566) on ‘Master Direction - Know Your Customer (KYC) Direction, 2016’, as amended from time to time (hereinafter referred to as ‘MD on KYC’).

## Chapter II

## Authorisation and Capital Requirements

## 5. Authorisation for PA Business

a. A bank does not require authorisation to carry out PA business.

b. A non-bank entity shall seek authorisation for operating as a PA by submitting an application through RBI’s [online portal](https://pravaah.rbi.org.in/pravaah/). An entity, regulated by any of the financial sector regulator(s), shall apply along with a ‘No Objection Certificate’ (NOC) from such regulator(s), within 45 days of obtaining the NOC.

c. A non-bank PA shall be a company incorporated in India under the Companies Act, 2013. The Memorandum of Association of the applicant entity should cover the proposed activity of operating as a PA.

d. Following is applicable from the date of these Directions:

i. A PA having a Certificate of Authorisation (CoA) issued by RBI, and

- already carrying on business as a PA-P – shall intimate RBI. A revised CoA shall be issued to the PA.

- desirous of commencing business in another PA category – shall intimate RBI at least 30 days prior to commencing the new business.

ii. An entity, whose application for grant of CoA for PA-O or PA – CB is under consideration of RBI – shall intimate the Reserve Bank about its existing PA-P business, if any, through the online portal, by December 31, 2025.

iii. An entity carrying on only PA-P business shall apply for authorisation as prescribed in 5 (b) above, by December 31, 2025. An entity which fails to apply by the due date shall intimate its banker(s) forthwith and wind up its business by February 28, 2026.

e. Application of an entity, not meeting the minimum capital requirement, or which is incomplete / not in the prescribed form, shall be returned.

## 6. Capital Requirements

a. An entity seeking authorisation to commence or carry on PA business shall have a minimum net-worth of ₹15 crore at the time of tendering application for authorisation; and shall attain a minimum net-worth of ₹25 crore by the end of third financial year of grant of authorisation.

b. The minimum networth, as applicable, shall be maintained by a PA on an ongoing basis.

c. For the purposes of this MD, computation of net worth of an entity shall be guided by the directions in [RBI circular DPSS.CO.AD.No.1344 02.27.005/2014-15 dated January 16, 2015](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=9490&Mode=0) on ‘Computation of Net-worth’, as amended from time to time. In addition to the items provided in the said circular, “net worth” shall also include preference shares that are compulsorily convertible to equity. Compulsorily convertible preference shares can be either non-cumulative or cumulative, and they should be compulsorily convertible into equity shares and the shareholder agreements should specifically prohibit any withdrawal of this preference share capital at any time. Additionally, if Deferred Tax Assets have been included in any of the components, the same shall be deducted while arriving at the net-worth value.

d. An entity, having Foreign Direct Investment (FDI), shall be guided by the Consolidated FDI Policy of the Government of India, and the relevant Foreign Exchange Management Regulations on this subject.

e. An entity seeking PA authorisation shall submit a certificate in the enclosed format ([Annexure 2.1](https://rbidocs.rbi.org.in/rdocs/content/pdfs/141MD15092025_AN21.pdf)) from their statutory auditor evidencing compliance with the applicable net-worth requirement while submitting the application for authorisation. A newly incorporated non-bank entity which may not have an audited statement of financial accounts shall submit a certificate in the enclosed format from their statutory auditor regarding current networth along with a provisional balance sheet as of recent date.

## Chapter III

## Conduct of PA business

## 7. Governance

a. A PA shall be professionally managed. The promoters and directors of the entity shall satisfy the fit and proper criteria as below:

i. The person has a record of fairness and integrity, including but not limited to:

- financial integrity;

- good reputation and character; and

- honesty;

ii. Such person has not incurred any of the following disqualifications:

- Convicted by a court for any offence involving moral turpitude or any economic offence or any offence under the laws administered by the RBI;

- Adjudged insolvent and not discharged;

- An order, restraining, prohibiting or debarring the person from accessing / dealing in any financial system, passed by any regulatory authority, and the period specified in the order has not elapsed;

- Found to be of unsound mind by a court of competent jurisdiction and the finding is in force; and

- Is financially not sound.

b. The promoters and directors of the applicant entity may submit a declaration in the enclosed format ([Annexure 2.5](https://rbidocs.rbi.org.in/rdocs/content/pdfs/141MD15092025_AN25.pdf)). RBI may also check ‘fit and proper’ status of the applicant entity and management thereof by obtaining inputs from other regulators, government departments, etc., as deemed fit. As regards fulfilment of ‘fit and proper’ criteria, RBI’s decision shall be final.

c. Any takeover or acquisition of control or change in the management of a non-bank PA shall adhere to [RBI circular CO.DPSS.POLC.No.S-590/02-14-006/2022-23 dated July 4, 2022](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12348&Mode=0) on ‘Requirement for obtaining prior approval in case of takeover / acquisition of control of non-bank PSOs and sale / transfer of payment system activity of non-bank PSO’, as amended from time to time. This provision shall also apply to an entity whose application for authorisation as PA is pending with RBI.

## 8. Dispute Management Framework

a. A PA shall have a dispute resolution mechanism to handle payment related disputes in transactions facilitated by it. The mechanism should also include timelines for processing refunds, etc. The policy shall ensure adherence to the instructions issued by RBI including on Turn Around Time (TAT) for resolution of failed transactions issued vide [DPSS.CO.PD No.629/02.01.014/2019-20 dated September 20, 2019](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11693&Mode=0) (as amended from time to time). This includes assigning of proper reason codes, responding to chargeback, disputes raised against their onboarded merchants, etc.

b. Agreements between a PA, its merchants, its acquiring banks, and all other stakeholders shall clearly delineate the roles and responsibilities of the involved parties, inter alia covering manner of refunds, treatment of failed transactions, return policy, grievance redressal, reconciliation, etc.

c. The PA shall disclose comprehensive information regarding its merchant policies, privacy policy and other terms and conditions on its website and / or its mobile application.

d. The PA shall appoint an officer responsible for responding to issues raised by its merchants along with an escalation matrix for grievance redressal. Details of the officer and escalation matrix shall be prominently displayed on its website.

## 9. Security, Fraud Prevention and Risk Management Framework

a. A strong risk management system is necessary to meet the challenges of fraud and ensure customer protection. PA shall put in place adequate Information and Data Security infrastructure and systems for detection and prevention of frauds. PA shall ensure that infrastructure of the merchants is compliant with security standards like PCI-DSS and PCI-SSF, as may be applicable.

b. PA shall put in place a Board approved Information Security Policy for safety and security of the payment systems operated by it and implement security measures in accordance with the said policy to mitigate identified as well as emerging risks. PA shall ensure adherence to baseline technology-related recommendations as provided in [Annexure 1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#ANN1).

c. PA shall comply with data storage requirements as applicable to Payment System Operators (PSOs) as laid out in [RBI circular DPSS.CO.OD No.2785/06.08.005/2017-2018 dated April 6, 2018](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11244&Mode=0) on ‘Storage of Payment System Data’, as amended from time to time.

d. An annual system audit, including cyber security audit, conducted by CERT-In empanelled auditors shall be carried out and report thereof shall be submitted to the respective Regional Office of DPSS, RBI within such timelines as may be prescribed by RBI.

e. The PA shall also be guided by [RBI circular CO.DPSS.OVRST.No.S447/06-26-002/2024-25 dated July 30, 2024](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12715) on ‘Master Directions on Cyber Resilience and Digital Payment Security Controls for non-bank Payment System Operators’, as amended from time to time.

## 10. General Directions

a. A PA shall aggregate funds only for the merchant with whom it has a contractual relationship.

b. A PA business shall not carry out marketplace business.

c. A PA shall ensure that the extant instructions with regard to Merchant Discount Rate (MDR) are followed. A PA shall also ensure that any charges, other than the price of goods / service / investment amount, charged by a merchant, are distinctly displayed to the payer prior to the transaction.

d. A PA shall not place limits on transaction amount for a particular payment mode. The responsibility thereof shall lie with the issuing bank / non-bank entity; for instance, the card issuing bank shall be responsible for placing transaction amount limits on cards issued by it based on the customer’s credit worthiness, spending nature, profile, etc.

e. A PA shall not give an option for ATM PIN as a factor of authentication for card-not-present transactions.

f. All refunds shall be made to the original method of payment, unless specifically instructed by the payer to credit the refund to an alternate mode belonging to the same payer.

g. A PG, as defined in paragraph 4(j), shall not fall within the scope of this MD. However, a PG is encouraged to adopt the baseline technology recommendations of the Reserve Bank of India (appended as [Annexure 1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#ANN1)).

h. A PA may avail services of a PG in terms of [RBI circulars DoS.CO.CSITEG/SEC.1/31.01.015/2023-24 dated April 10, 2023](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12486) on ‘Master Direction on Information Technology Services’, [CO.DPSS.POLC.No.S-384/02.32.001/2021-2022 dated August 3, 2021](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12136&Mode=0) on ‘Framework for Outsourcing of Payment and Settlement-related Activities by Payment System Operators’, and [DBOD.NO.BP.40/21.04.158/2006-07 dated November 3, 2006](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=3148&Mode=0) on ‘Managing Risks and Code of Conduct in Outsourcing of Financial Services by banks’, as applicable and amended from time to time.

## 11. Specific Directions applicable to PA – CB

a. Funds related to inward and outward transactions as carried out by a PA-CB shall be kept separate. No co-mingling of funds or netting off for outward and inward transactions is permitted under any circumstance.

b. For outward transactions, a PA - CB may directly on-board merchants located abroad or enter into agreement with e-commerce marketplaces or entities providing PA services abroad.

c. Outward transactions can be carried out using any payment instrument provided by authorised payment systems in India, except small Prepaid Payment Instrument.

d. A PA-CB shall not purchase foreign currency from, or sell it to, any entity other than an Authorised Dealer (AD). In respect of inward or outward transactions processed by a PA - CB, the maximum value per transaction shall be ₹25 lakh.

e. AD-I banks maintaining Inward Collection Accounts (InCAs) / Outward Collection Accounts (OCAs), as defined in paragraph 16a. below of this MD, shall ensure that all requirements under FEMA are adhered to.

f. AD-I Bank shall have automated processes to fetch the requisite information from a PA – CB.

g. To establish the bonafides of a transaction, the payment transaction (outward / inward) shall be identified as a cross-border transaction. A Payment System Provider shall make provisions for implementation of the same from such timelines as specified by RBI.

h. PA – CB shall provide the documents / information required by the exporter / importer to the AD bank of the exporter / importer, for closure of their corresponding entry in Export Data Processing and Monitoring System (EDPMS) / Import Data Processing and Management System (IDPMS), wherever applicable, (for the respective inward / outward remittance), in compliance with the extant directions.

i. Settlement in non-INR currencies shall be permitted only for those merchants (Indian exporters) which have been directly onboarded by the PA – CB facilitating inward transactions.

## 12. Reports

An authorised PA shall submit reports as listed in [Annexure 2](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#ANN2) of this MD.

## Chapter IV

## KYC and Due Diligence

## 13. Due Diligence by PA

a. A PA shall undertake customer due diligence (CDD) of its merchants in accordance with MD on KYC. While onboarding, the PA shall, with the merchant’s consent, retrieve the merchant’s KYC record from CKYCR. The process defined in MD on KYC should be followed in case CKYCR record is found to be not updated.

b. Where a merchant’s record is not available in CKYCR, or a PA cannot access CKYCR as its application for authorisation is pending with the Reserve Bank, CDD of the merchant could be carried out through other mechanisms outlined in MD on KYC. If the merchant’s annual turnover does not exceed ₹40 lakh, or its annual export turnover does not exceed ₹5 lakh, the following process could also be adopted as an alternative:

- Obtain a copy of the PAN / Form 60 of the merchant and verify the PAN from issuing authority.

- Conduct CPV of the merchant.

- Obtain a certified copy of one officially valid document (OVD) of the proprietor or of the person holding power of attorney to operate the account, as applicable. One of the documents or the equivalent e-documents, as prescribed for CDD of sole-proprietary firms or legal entities, should be verified.

c. A PA shall undertake background and antecedent check of the merchant.

d. In case a PA contracts with another PA that onboards the merchant, the latter is responsible for carrying out due diligence of the merchant.

e. PA shall facilitate allotment of appropriate Merchant Category Code and Merchant ID / Terminal ID to its merchants including those onboarded through an overseas PA. PA shall ensure that name of the merchant is captured appropriately for all transactions processed for it.

f. A PA shall ensure that a marketplace onboarded by it does not accept payments for a seller not onboarded on to the marketplace’s platform.

g. Necessary validation mechanisms shall be put in place by a PA to ensure that funds due to a merchant are credited in the merchant’s bank account only.

h. The PA must also monitor transactions subsequently undertaken by the merchants to ensure that these transactions are in line with latter’s business profile and ensure adherence to other aspects of MD on KYC while conducting its operations.

i. Non-bank PA shall register itself with the Financial Intelligence Unit-India (FIU-IND) in compliance with MD on KYC and meet the reporting requirements listed therein.

j. A PA, including an existing PA whose application is pending with Reserve Bank of India for authorisation, shall ensure that merchants onboarded till December 31, 2025, comply with the above due diligence requirements within one year from the date of this MD. From January 1, 2026, merchants should be onboarded in accordance with due diligence requirements prescribed in this MD.

## 14. Responsibilities of Acquiring Bank

a. Acquiring bank shall have a policy for processing payments for merchants acquired through an authorised non-bank PA.

b. Acquiring bank need not undertake the customer due diligence of the merchant itself but should be able to obtain the required details whenever required.

c. Acquiring Bank of a non-bank PA shall ensure that merchants onboarded by the PA are in compliance with acquiring bank’s policy for merchant acquiring.

## 15. Due Diligence through assisted mode

a. A non-bank PA may utilise agents to undertake the following activities related to due diligence of merchants:

- Digital KYC process as provided in Annex–I of MD – KYC (in lieu of Business Correspondents)

- Assisted V-CIP, only by the agent assisting the individual / proprietor / power of attorney holder / beneficial owner / authorised signatory of the merchant, in terms of Paragraph 18 of MD on KYC. PA shall maintain the details of the agent assisting the merchant, where services of such agents are employed.

b. The non-bank PA shall carry out due diligence of the persons appointed as authorised / designated agents.

c. The ultimate responsibility of due diligence shall lie on PA and agents can only be used for limited purposes as prescribed above.

## Chapter V

## Settlement of funds and Escrow accounts

## 16. Escrow accounts of PA

a. A non-bank PA shall maintain the funds collected on behalf of its merchants in a separate escrow account with any Scheduled Commercial Bank (SCB) in India. In case of a PA – CB, such account shall also be referred to as Inward Collection Account (InCA) for inward transactions and Outward Collection Account (OCA) for outward transactions, as applicable. Details of operations in escrow accounts are incorporated in [Table 1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#T1) below and the instructions mentioned therein must be adhered to by December 31, 2025. Such escrow accounts shall only be utilised for authorised PA business and not for any other business.

| Table 1 - Escrow Account Requirements |  |  |  |
| --- | --- | --- | --- |
| Particulars | Escrow Account (Domestic) | Inward Collection Account (InCA) | Outward Collection Account (OCA) |
| General requirements |  |  |  |
| Opened with | SCB. | Authorised Dealer Category-I SCB. | Authorised Dealer Category-I SCB. |
| Account constitutes | Collection of funds on behalf of merchants onboarded by PA. | Collection of proceeds of inward transactions on behalf of merchants onboarded by PA. | Collection of proceeds of outward transactions to the overseas sellers onboarded by PA-CB. |
| Currency | INR | Separate account for INR and / or each non-INR currency. | INR |
| Operational requirements |  |  |  |
| Pre-funding | Allowed. | Not permitted. |  |
| Withdrawal of pre-funding | Not permitted. | Not applicable. |  |
| Additional Escrow Account (at the discretion of PA) | One additional account may be maintained in a different SCB. | One additional account may be maintained in a different SCB (for each currency). | One additional account may be maintained in a different SCB. |
| Inter-escrow A/c transfer | Auditor’s certificate needed for such transactions. | Not permitted. |  |
| Permitted credits | i) Receipt of funds from payers for merchants, onboarded towards purchase of goods / services / investments; ii) Receipt of funds from other PAs for settlement to their merchant iii) Refunds thereof initiated by merchants (failed / disputed / returned / cancelled transactions) iv) Pre-funding through own / merchant’s funds. v) Payment received for onward transfer to merchants under promotional activities, incentives, cash-backs, etc. | Same as that of Escrow Account (Domestic) except iv). |  |
| Permitted debits | i) Payments to onboarded merchants, towards sale of goods/services/investments and amount received under promotional activities, incentives, cashbacks, etc. ii) Refund to be credited to the payer for the reversals of purchase transactions, iii) Payment to another PA or PA – CB facilitating outward transactions which is part of the transaction flow, for ultimate settlement of funds to the merchant. Note: This permitted debit shall not be used to transfer funds from an entity acting as a BBPOU, as defined in Master Direction on BBPS to its BBPS escrow account except in case where the entity acts as a PA to an Agent Institution and on its behalf transfers funds to the BBPS escrow account of the BBPOU. iv) Payment to any other account (third party), on specific direction of a merchant, having physical or online presence with an annual turnover above ₹40 lakh or an annual export turnover of more than ₹5 lakh, provided the third party is the payee that interfaces with the payer for purchase / delivery of goods, services or investment products, for the underlying transaction. v) Payment of commission to the PA. | Same as that of Escrow Account (Domestic), except iv). |  |
| Maintenance of day end balance in escrow account | Shall not be less than the amount realised in escrow towards funds payable to the merchants, but not settled to them. |  |  |
| Interest-bearing | No interest shall be payable on the balances maintained in the escrow account(s) except on the core portion amount of the domestic escrow account, subject to the conditions prescribed in paragraph 17 below. | No interest shall be payable on the balances. |  |
| Timelines |  |  |  |
| Escrow a/c by existing PA | Within two months from the date of authorisation by the Reserve Bank of India. PA may migrate funds to an escrow account prior to authorisation but protection under paragraph 16 (b) of these Directions shall be available only after authorisation. |  |  |
| Credit to merchant’s a/c | As per the agreement between the PA and the merchant. Such an agreement should be fair, equitable and must transparently mention the settlement timelines. |  |  |
| Note: (a) An entity authorised to carry out PA-O and PA-P businesses shall use the same escrow account for both the business activities. (b) For the purposes of these directions, ‘Core Portion’ shall be computed as under: Step 1: Compute lowest daily outstanding balance (LB) in the escrow account on a fortnightly (FN) basis, for 26 fortnights from the preceding month. Step 2: Calculate the average of the lowest fortnightly outstanding balances [(LB1 of FN1+ LB2 of FN2+ ........+ LB26 of FN26) divided by26]. Step 3: The average balance so computed represents the "Core Portion" eligible to earn interest. |  |  |  |

b. For the purposes of maintenance of an escrow account, payment system operated by PA shall be deemed to be ‘designated payment systems’ under Section 23A of the Payment and Settlements Systems Act, 2007.

## 17. Core portion of escrow accounts

a. The core portion of escrow account shall continue to be maintained within the escrow account maintained for PA activity.

b. This facility shall be permissible to entities who have been in business for twenty-six (26) fortnights and whose accounts have been duly audited for the full accounting year. For this purpose, the period of twenty-six fortnights shall be calculated from the date of actual business operation in the account.

c. No loan is permissible against the core portion. Banks shall not issue any receipt for such deposits which may entitle PA to the funds available in the core portion or mark any lien on the amount held in such form of deposits.

d. The core portion shall be calculated separately for each escrow account. The escrow balance maintained shall be clearly disclosed in the auditor’s certificates to be submitted to RBI on quarterly and annual basis.

## 18. General directions on Escrow account of PA

a. PA shall submit the list of merchants onboarded by it to the bank where it is maintaining the escrow account and update the list prior to initiating settlement to these merchants. This list includes eligible third parties to which PA – O or PA - P would be settling funds on the instructions of the merchant as detailed in permitted debits in [Table 1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#T1) above. The bank shall ensure that payments are made only to eligible merchants and for permissible debits or credits as defined under this MD. There shall be an exclusive clause in the agreement signed between the PA and the bank maintaining escrow account towards usage of balance in escrow account only as per the permissible debits or credits as mentioned in [Table 1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#T1) above.

b. The escrow account shall not be operated for ‘Cash-on-Delivery’ transactions.

c. Funds for an outward transaction may be received in the escrow account of the PA (and then transferred to the OCA of PA – CB) or directly in OCA of the PA - CB. Onward transfer to the foreign merchants shall be carried out only by debit to the OCA.

d. In case a PA-CB also engages in domestic PA activity, InCA and OCA shall be kept separate from the escrow account(s) opened for such domestic PA activity.

e. A certificate, signed by the statutory auditor(s), shall be submitted by the authorised entities to the respective Regional Office of DPSS, RBI, where registered office of PA is situated, certifying that the entity has been maintaining balance(s) in the escrow account(s) in compliance with these instructions, as per periodicity prescribed in [Annexure 2](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#ANN2). In case an additional escrow account is being maintained, it shall be ensured that balances in both accounts are considered for the above certification and that these are separately mentioned in the certificate. The certificates shall be submitted separately for domestic activity, i.e. PA – O / P and cross border activity, i.e. PA – CB.

f. In case there is a need to shift the escrow account from one bank to another, the same shall be effected in a time-bound manner without impacting the payment cycle to merchants, under advice to RBI.

g. For banks, the outstanding balance in the escrow account shall be part of the ‘net demand and time liabilities’ (NDTL) for the purposes of maintenance of reserve requirements. This position shall be computed on the basis of balances appearing in the books of the bank as on the date of reporting.

h. Credits towards reversed transactions (where funds are received by PA) and refund transactions shall be routed back through the escrow account unless the refund is directly managed by the merchant and the payer has been made aware of the same, in terms of the contract between a PA and merchant. The chargeback rights of customers, as applicable, shall remain unaffected.

## Chapter VI

## Repeal and Savings

19. The following circulars are hereby repealed except for an existing PA – CB which had applied for authorisation as PA – CB on or before April 30, 2024 and a decision thereon is pending with the Reserve Bank of India:

a. [A.P. (DIR Series) Circular No. 17 dated November 16, 2010](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=6107&Mode=0) on ‘Processing and Settlement of Export related receipts facilitated by Online Payment Gateways’

b. [A.P. (DIR Series) Circular No. 109 dated June 11, 2013](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=8030&Mode=0) on ‘Processing and Settlement of Export related receipts facilitated by Online Payment Gateways – Enhancement of the value of transaction’

c. [A.P. (DIR Series) Circular No.16 dated September 24, 2015](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=10037&Mode=0) on ‘Processing and settlement of import and export related payments facilitated by Online Payment Gateway Service Providers’.

20. The [circular DPSS.CO.PD.No.1102/02.14.08/2009-10 dated November 24, 2009](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=5379&Mode=0) on ‘Directions for opening and operation of Accounts and settlement of payments for electronic payment transactions involving intermediaries’ is hereby repealed except only in relation to an existing PA – O which has sought authorisation and a decision thereon is pending with the Reserve Bank of India.

21. Save as provided herein, circulars listed in [Annexure–3](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896#ANN3) stands repealed with the issuance of this MD.

22. Notwithstanding such repeal as aforementioned, all authorisation / approvals granted, actions taken, and acknowledgements issued under the aforesaid circulars/ Directions shall continue to be valid and shall be deemed to have been granted under this MD.

23. The circulars, directions and guidelines so repealed shall be deemed to have been in force until the date of coming into effect of this MD.

---

## Annexure-1

## Baseline Technology-related Recommendations

Indicative baseline technology-related recommendations for adoption by the PAs (mandatory) and PGs (recommended) are:

## 1. Security-related Recommendations

The requirements for the entities in respect of IT systems and security are presented below:

1.1. Information Security Governance: The entities at a minimum shall carry out comprehensive security risk assessment of their people, IT, business process environment, etc., to identify risk exposures with remedial measures and residual risks. These can be an internal security audit or an annual security audit by an independent security auditor or a CERT-In empanelled auditor. Reports on risk assessment, security compliance posture, security audit reports and security incidents shall be presented to the Board.

1.2. Data Security Standards: Data security standards and best practices like PCI-DSS, PCI-SSF, latest encryption standards, transport channel security, etc., shall be implemented.

1.3. Security Incident Reporting: The entities shall report security incidents / card holder data breaches to RBI within the stipulated timeframe to RBI. Monthly cyber security incident reports with root cause analysis and preventive actions undertaken shall be submitted to RBI.

1.4. Merchant Onboarding: The entities shall undertake comprehensive security assessment during merchant onboarding process to ensure these minimal baseline security controls are adhered to by the merchants.

1.5. Cyber Security Audit and Reports: The entities shall carry out and submit to the IT Committee quarterly internal and annual external audit reports; bi-annual Vulnerability Assessment / Penetration Test (VAPT) reports; PCI-DSS including Attestation of Compliance (AOC) and Report of Compliance (ROC) compliance report with observations noted if any including corrective / preventive actions planned with action closure date; inventory of applications which store or process or transmit customer sensitive data; PCI-SSF compliance status of payment applications which stores or processes card holder data.

1.6. Information Security: Board approved information security policy shall be reviewed atleast annually. The policy shall consider aspects like: alignment with business objectives; the objectives, scope, ownership and responsibility for the policy; information security organisational structure; information security roles and responsibilities; maintenance of asset inventory and registers; data classification; authorisation; exceptions; knowledge and skill sets required; periodic training and continuous professional education; compliance review and penal measures for non-compliance of policies.

1.7. IT Governance: An IT policy shall be framed for regular management of IT functions and ensure that detailed documentation in terms of procedures and guidelines exists and are implemented. The strategic plan and policy shall be reviewed annually. The Board level IT Governance framework shall have-

1.7.1. Involvement of Board: The major role of the Board / Top Management shall involve approving information security policies, establishing necessary organisational processes / functions for information security and providing necessary resources.

1.7.2. IT Steering Committee: An IT Steering Committee shall be created with representations from various business functions as appropriate. The Committee shall assist the Executive Management in implementation of the IT strategy approved by the Board. It shall have well defined objectives and actions.

1.7.3. Enterprise Information Model: The entities shall establish and maintain an enterprise information model to enable applications development and decision-supporting activities, consistent with board approved IT strategy. The model shall facilitate optimal creation, use and sharing of information by a business, in a way that it maintains integrity, and is flexible, functional, timely, secure and resilient to failure.

1.7.4. Cyber Crisis Management Plan: The entities shall prepare a comprehensive Cyber Crisis Management Plan approved by the IT strategic committee and shall include components such as Detection, Containment, Response and Recovery.

1.8. Enterprise Data Dictionary: The entities shall maintain an “enterprise data dictionary” incorporating the organisation’s data syntax rules. This shall enable sharing of data across applications and systems, promote a common understanding of data across IT and business users and prevent creation of incompatible data elements.

1.9. Risk Assessment: The risk assessment shall, for each asset within its scope, identify the threat / vulnerability combinations and likelihood of impact on confidentiality, availability or integrity of that asset – from a business, compliance and / or contractual perspective.

1.10. Access to Application: There shall be documented standards / procedures for administering an application system, which are approved by the application owner and kept up-to-date. Access to the application shall be based on the principle of least privilege and “need to know” commensurate with the job responsibilities.

1.11. Competency of Staff: Requirements for trained resources with requisite skill sets for the IT function need to be understood and assessed appropriately with a periodic assessment of the training requirements for human resources.

1.12. Vendor Risk Management: The Service Level Agreements (SLAs) for technology support, including BCP-DR and data management shall categorically include clauses permitting regulatory access to these set-ups.

1.13. Maturity and Roadmap: The entities shall consider assessing their IT maturity level, based on well-known international standards, design an action plan and implement the plan to reach the target maturity level.

1.14. Cryptographic Requirement: The entities shall select encryption algorithms which are well established international standards and which have been subjected to rigorous scrutiny by an international community of cryptographers or approved by authoritative professional bodies, reputable security vendors or government agencies.

1.15. Forensic Readiness: All security events from the entities infrastructure including but not limited to application, servers, middleware, endpoint, network, authentication events, database, web services, cryptographic events and log files shall be collected, investigated and analysed for proactive identification of security alerts.

1.16. Data Sovereignty: The entities shall take preventive measures to ensure storing data in infrastructure that do not belong to external jurisdictions. Appropriate controls shall be considered to prevent unauthorised access to the data.

1.17. Data Security in Outsourcing: There shall be an outsourcing agreement providing ‘right to audit’ clause to enable the entities / their appointed agencies and regulators to conduct security audits. Alternatively, third parties shall submit annual independent security audit reports to the entities.

1.18. Payment Application Security: Payment applications shall be developed as per PCI-SSF guidelines and complied with as required. The entities shall review PCI-DSS compliance status as part of merchant onboarding process.

## 2. Other Recommendations

2.1 The customer card credentials shall not be stored within the database or the server accessed by the merchant.

2.2 Option for ATM PIN as a factor of authentication for card not present transactions shall not be given.

2.3 Instructions on storage of payment system data, as applicable to PSOs, shall apply.

2.4 All refunds shall be made to original method of payment unless specifically agreed by the customer to credit an alternate mode.

---

## Annexure-2

## Reports to be submitted by Authorised Payment Aggregators

## Annual

1. Net-worth Certificate - Audited Annual report with statutory auditor certificate on Net-worth – by September 30th ([Annexure 2.1](https://rbidocs.rbi.org.in/rdocs/content/pdfs/141MD15092025_AN21.pdf)).

2. IS Audit Report and Cyber Security Audit Report with observations noted, if any, including corrective / preventive action planned with closure date – Externally Audited – as prescribed by RBI. The scope of audit shall encompass all relevant areas of information system processes and applications.

## Quarterly

1. Auditor’s Certificate on Maintenance of Balance in Escrow Account – by 15th of the month following the quarter end. ([Annexure 2.2](https://rbidocs.rbi.org.in/rdocs/content/pdfs/141MD15092025_AN22.pdf) and [Annexure 2.3](https://rbidocs.rbi.org.in/rdocs/content/pdfs/141MD15092025_AN23.pdf)).

2. Bankers’ Certificate on Escrow Account Debits and Credits – Internally Audited – by 15th of the month following the quarter end in case of PA – O and PA – P.

3. Bankers’ Certificate on InCA / OCA Debits and Credits – Internally Audited – by 15th of the month following the quarter end in case of PA - CB.

## Monthly

1. Statistics of Transactions Handled – by 7th of next month ([Annexure 2.4](https://rbidocs.rbi.org.in/rdocs/content/pdfs/141MD15092025_AN24.pdf)).

## Non-periodic

1. Declaration and Undertaking by the Director - Changes in Board of Directors – as and when happens. – ([Annexure 2.5](https://rbidocs.rbi.org.in/rdocs/content/pdfs/141MD15092025_AN25.pdf))

---

## Annexure–3

## List of circulars repealed with the issuance of this Master Direction

| S.No. | Circular No. | Date | Subject |
| --- | --- | --- | --- |
| 1. | [DPSS.CO.PD.No.1810/02.14.008/2019-20](https://rbi.org.in/Scripts/NotificationUser.aspx?Id=11822&Mode=0) | March 17, 2020 | Guidelines on Regulation of Payment Aggregators and Payment Gateways |
| 2. | [CO.DPSS.POLC.No.S33/02-14-008/2020-2021](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12050&Mode=0) | March 31, 2021 | Guidelines on Regulation of Payment Aggregators and Payment Gateways |
| 3. | [CO.DPSS.POLC.No.S-786/02-14-008/2023-24](https://rbi.org.in/Scripts/NotificationUser.aspx?Id=12561&Mode=0) | October 31, 2023 | Regulation of Payment Aggregator – Cross Border (PA - Cross Border) |
