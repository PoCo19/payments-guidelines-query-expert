# Digital Payments – E-mandate Framework, 2026

RBI/DPSS/2026-27/396
RBI/CO.DPSS.POLC.No.S56/02.14.003/2026-27

April 21, 2026

Index

[Introduction](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#12)

[Short Title and Commencement](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#1)

[Applicability](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#2)

[Definitions](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#3)

[Registration and revocation of E-mandate](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#4)

[Processing of First Transaction and Subsequent Recurring Transactions](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#5)

[Pre-Transaction Notification](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#6)

[Post-Transaction Notification](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#7)

[Transaction Limits and Velocity Check](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#8)

[Dispute Resolution and Grievance Redressal](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#9)

[Other Provisions](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#10)

[Repeal](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#11)

## Digital Payments – E-mandate Framework, 2026

In exercise of the powers conferred by Sections 10(2) read with Section 18 of the Payment and Settlement Systems (PSS) Act, 2007, the Reserve Bank of India (RBI), being satisfied that it is necessary and expedient in the public interest so to do, hereby consolidates all circulars pertaining to e-mandates and issues the Directions hereinafter specified.

## 1. Short Title and Commencement

(a) These Directions shall be called the “Digital Payments - E-mandate Framework, 2026”.

(b) These Directions shall be effective immediately.

## 2. Applicability

The provisions of these Directions shall be applicable to all Payment System Providers and Payment System Participants in respect of processing of recurring transactions, domestic or cross-border, using cards / PPI / UPI.

## 3. Definitions

(a) The terms ‘authentication’, ’factor of authentication’, ‘issuer’, ‘merchant’ will have the same meaning as defined in [Reserve Bank of India (Authentication mechanisms for digital payment transactions) Directions, 2025 dated September 25, 2025](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12898&Mode=0) and [Master Direction on Regulation of Payment Aggregator (PA) dated September 15, 2025](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12896).

## 4. Registration and revocation of E-Mandate

(a) A customer desirous of opting for e-mandate facility shall undertake a one-time registration process. The mandate shall be registered only after successful validation of additional factor of authentication (AFA), in addition to the normal process required by the issuer.

(b) Every e-mandate registered by the issuer shall specify the validity period of the e-mandate. The issuer shall provide the customer with a facility to modify the validity period or withdraw the e-mandate at any point of time. Information about this facility shall be clearly communicated to the customer at the time of registration.

(c) The e-mandate may be for either a pre-specified fixed amount or for a variable amount subject to the overall cap fixed by the RBI. In the case of variable e-mandates, the issuer shall provide the customer with a facility to specify the maximum value of any recurring transaction.

(d) The customer shall be given a facility to choose or change a mode among available options (SMS, email, etc.) for receiving the pre-transaction notification from the issuer.

(e) Any modification in, or withdrawal of, an existing e-mandate shall require AFA validation by the issuer.

## 5. Processing of first transaction and subsequent recurring transactions

(a) The first transaction under an e-mandate shall require AFA validation. If the first transaction is processed along with registration of the e-mandate, then AFA validation may be combined.

(b) Payments under e-mandates shall not be subject to any other limits / controls set by the customer.

## 6. Pre-transaction Notification

(a) An issuer shall send a pre-transaction notification to the customer, at least 24 hours prior to the actual charge / debit.

(b) The pre-transaction notification shall, at the minimum, inform the customer about the merchant’s name, transaction amount, date / time of debit, reference number of e-mandate, reason for debit, i.e., e-mandate registered by the customer.

(c) The issuer shall provider a customer with a facility to opt-out of any particular transaction or the e-mandate. Any such opt-out shall be validated by the issuer using AFA. An intimation to this effect shall be sent to the customer.

(d) Pre-transaction notification is not required for e-mandates registered to auto-replenish balances of FASTag, and National Common Mobility Card (NCMC).

## 7. Post-transaction notification

An issuer shall send a post-transaction notification to the customer. This notification shall, at the minimum, inform the customer about the merchant’s name, transaction amount, date and time of debit, reference number of transaction and e-mandate, reason for debit, i.e., e-mandate registered by the customer, and details on grievance redressal [[1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#F1)] .

## 8. Transaction limits and velocity check

(a) All recurring transactions may be authorised without AFA up to ₹15,000/- per transaction. Transactions above this amount shall be subject to AFA.

(b) Payment of insurance premiums, subscription to mutual funds, and credit card bill payments may be made without AFA up to ₹1,00,000/- per transaction.

## 9. Dispute resolution and grievance redressal

(a) An appropriate dispute redressal system shall be put in place by the issuer to facilitate the customer to lodge grievance/s.

(b) RBI instructions on limiting liability of customers for unauthorised transactions shall be applicable to recurring transactions under e-mandates as well.

## 10. Other provisions

(a) No charges shall be levied to the customer for availing the e-mandate facility for recurring transactions.

(b) In case of cards, existing e-mandate(s) can be mapped to reissued cards [[2](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=13374#F2)] .

(c) An acquirer shall ensure compliance with these directions by merchants on-boarded by them.

## 11. Repeal

With the issue of these directions, the instructions/guidelines contained in the following circulars, issued by the Reserve Bank stand repealed.

| No | Circular No. | Date | Subject |
| --- | --- | --- | --- |
| 1. | [DPSS.CO.PD.No.447/02.14.003/2019-20](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11668&Mode=0) | August 21, 2019 | Processing of e-mandate on cards for recurring transactions |
| 2. | [DPSS.CO.PD No.1324/02.23.001/2019-20](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11784&Mode=0) | January 10, 2020 | Processing of e-mandate in Unified Payments Interface (UPI) for recurring transactions |
| 3. | [DPSS.CO.PD No.754/02.14.003/2020-21](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12002&Mode=0) | December 04, 2020 | Processing of e-mandates for recurring transactions |
| 4. | [CO.DPSS.POLC.No.S34/02-14-003/2020](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12051&Mode=0) | March 31, 2021 | Framework for processing of e-mandates for recurring online transactions |
| 5. | Clarification issued to IBA on e-mandate based recurring transactions | October 08, 2021 | RBI's framework for e-mandate based recurring transactions |
| 6. | [CO.DPSS.POLC.No.S-518/02.14.003/2022-23](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12341&Mode=0) | June 16, 2022 | Processing of e-mandates for recurring transactions |
| 7. | [CO.DPSS.POLC.No.S-882/02.14.003/2023-24](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12570&Mode=0) | December 12, 2023 | Processing of e-mandates for recurring transactions |
| 8. | [CO.DPSS.POLC.No.S528/02-14-003/2024-25](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12722&Mode=0) | August 22, 2024 | Processing of e-mandates for recurring transactions |

---

[1]  The requirement for providing details of grievance redressal is added, based on feedback.

[2]  This clause is added based on feedback.
