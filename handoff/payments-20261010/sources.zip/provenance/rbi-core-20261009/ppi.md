# Master Directions on Prepaid Payment Instruments (PPIs) (Updated as on September 30, 2026)

RBI/DPSS/2021-22/82
CO.DPSS.POLC.No.S-479/02.14.006/2021-22

August 27, 2021
(Updated as on September 30, 2026)
(Updated as on December 27, 2024)
(Updated as on February 23, 2024)
(Updated as on February 10, 2023)
(Updated as on November 12, 2021)

All Prepaid Payment Instrument Issuers (Banks and Non-banks) and System Participants

Madam / Dear Sir,

## Master Directions on Prepaid Payment Instruments (PPIs)

This has reference to the [Master Direction dated October 11, 2017](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=11142) on Issuance and Operation of Prepaid Payment Instruments (PPI-MD) and subsequent amendments made thereto. Keeping in view the recent updates to PPI guidelines, it has been decided to issue the [Master Directions](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12156#MD) afresh.

2. These Directions are issued under Section 18 read with Section 10(2) of the Payment and Settlement Systems Act, 2007.

Yours faithfully,

(P. Vasudevan)
Chief General Manager

---

## Master Directions on Prepaid Payment Instruments (MD-PPIs)

## 1. Introduction

1.1 In exercise of the powers conferred under Section 18 read with Section 10(2) of the Payment and Settlement Systems Act, 2007 (Act 51 of 2007), the Reserve Bank of India (RBI) being satisfied that it is necessary and expedient in the public interest to do so, hereby, issues these Directions.

1.2 Short title and commencement

- These Directions shall be called the Reserve Bank of India Master Directions on Prepaid Payment Instruments, 2021 (MD-PPIs, 2021); and

- These Directions shall come into effect from the date they are placed on RBI website. However, in respect of instructions already issued, they shall be effective as per the respective timelines prescribed.

1.3 Applicability: The provisions of MD-PPIs shall apply to all Prepaid Payment Instrument (PPI) Issuers and System Participants.

1.4 Purpose

- To provide a framework for authorisation, regulation and supervision of entities issuing and operating PPIs in the country;

- To foster competition and encourage innovation in this segment in a prudent manner while taking into account safety and security of systems and transactions along with customer protection and convenience; and

- To provide for harmonisation and interoperability of PPIs.

1.5 Banks and non-bank entities issue PPIs in the country after obtaining necessary approval / authorisation from RBI under the Payment and Settlement Systems Act, 2007 (PSS Act). Taking into account the developments in the field and the progress made by PPI issuer, the existing instructions issued on the subject till date have been incorporated and are consolidated in these Master Directions (MD).

1.6 The MD lays down the eligibility criteria and the conditions of use for Payment System Operators (PSOs) involved in the issuance and operation of PPIs in the country.

1.7 No entity can set up and operate payment systems for PPIs without prior approval / authorisation of RBI.

## 2. Definitions

For the purpose of this MD, the following definitions shall be applicable:

2.1 Closed System PPIs : These PPIs are issued by an entity for facilitating the purchase of goods and services from that entity only and do not permit cash withdrawal. These instruments cannot be used for payment or settlement for third party services. The issuance or operation of such instruments is not classified as a payment system requiring approval / authorisation by RBI and are, therefore, not regulated or supervised by RBI.

2.2 Entities / Entity : The term ‘entities / entity’ refer/s to banks / non-banks who have approval / authorisation from RBI to issue PPIs as well as those who are proposing to issue PPIs.

2.3 Holder : Individuals / Organisations who obtain / purchase PPIs from the issuer and use them for purchase of goods and services, financial services, remittance facilities, etc.

2.4 Issuer : Entities issuing PPIs to individuals / organisations.

2.5 Limits : All limits in the value of instruments stated in this MD, indicate the maximum value of such instruments denominated in INR that shall be issued.

2.6 Merchants : Establishments who have a specific contract to accept the PPIs of the PPI issuer (or contract through a payment aggregator / payment gateway) against the sale of goods and services, financial services, etc.

2.7 Net-worth : Shall consist of ‘paid up equity capital, preference shares which are compulsorily convertible into equity capital, free reserves, balance in share premium account and capital reserves representing surplus arising out of sale proceeds of assets but not reserves created by revaluation of assets’ adjusted for ‘accumulated loss balance, book value of intangible assets and deferred revenue expenditure, if any’. While compulsorily convertible preference shares reckoned for computation of net-worth can be either non-cumulative or cumulative, these shall be compulsorily convertible into equity shares and the shareholder agreements shall specifically prohibit any withdrawal of this preference share capital at any time.

2.8 Prepaid Payment Instruments (PPIs) [[1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12156#F1)]  : Instruments that facilitate purchase of goods and services, financial services, remittance facilities, etc., against the value stored therein. PPIs that require RBI approval / authorisation prior to issuance are classified under two types viz. (i) Small PPIs, and (ii) Full-KYC PPIs.

- Small PPIs : Issued by banks and non-banks after obtaining minimum details of the PPI holder. They shall be used only for purchase of goods and services. Funds transfer or cash withdrawal from such PPIs shall not be permitted. Small PPIs can be used at a group of clearly identified merchant locations / establishments which have a specific contract with the issuer (or contract through a payment aggregator / payment gateway) to accept the PPIs as payment instruments. The features of these instruments are explained in paragraph 9.1 of this MD.

- Full-KYC PPIs : Issued by banks and non-banks after completing Know Your Customer (KYC) of the PPI holder. These PPIs shall be used for purchase of goods and services, funds transfer or cash withdrawal. The features of these instruments are explained in paragraph 9.2 of this MD.

## 3. Eligibility requirements for issuance of PPIs by banks

3.1 Banks that comply with the eligibility criteria, including those stipulated by the respective regulatory department of RBI, shall be permitted to issue PPIs after obtaining approval from RBI. Banks, seeking approval from the RBI under the PSS Act, shall apply to the Department of Payment and Settlement Systems (DPSS), Central Office (CO), RBI, Mumbai along with a ‘No Objection Certificate’ from their regulatory department, within 30 days of obtaining such clearance.

## 4. Capital and other eligibility requirements for issuance of PPIs by non-banks

4.1 Non-banks that comply with the eligibility criteria, including those stipulated by the respective regulatory department of RBI, shall be permitted to issue PPIs after obtaining authorisation from RBI. Non-banks, regulated by any of the financial sector regulators, seeking authorisation from the RBI under the PSS Act shall apply to the DPSS, CO, RBI, Mumbai along with a ‘No Objection Certificate’ from their respective regulator, within 30 days of obtaining such clearance.

4.2 Non-bank entities applying for authorisation shall be a company incorporated in India and registered under the Companies Act, 1956 / 2013.

4.3 Non-bank entities having Foreign Direct Investment (FDI) / Foreign Portfolio Investment (FPI) / Foreign Institutional Investment (FII) shall also meet the capital requirements as applicable under the extant Consolidated FDI policy guidelines of Government of India.

4.4 The Memorandum of Association (MoA) of the non-bank entity shall cover the proposed activity of PPI issuance.

4.5 All non-bank entities seeking authorisation from RBI under the PSS Act shall have a minimum positive net-worth of Rs.5 crore as per the latest audited balance sheet at the time of submitting the application. They shall submit a certificate in the enclosed format ([Annex-2](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_2.pdf)) from their Chartered Accountants (CA) to evidence compliance with the applicable net-worth requirement while submitting the application for authorisation. The application shall be processed by RBI based on this net-worth which shall be maintained at all times. Thereafter, by the end of the third financial year from the date of receiving final authorisation, they shall achieve a minimum positive net-worth of Rs.15 crore which shall be maintained at all times. Illustratively, if the entity is issued final authorisation on March 1, 2021, then it shall achieve a minimum positive net-worth of Rs.15 crore for the financial position as on March 31, 2023. Similarly, if the entity is issued final authorisation on May 1, 2021, then it shall achieve a minimum positive net-worth of Rs.15 crore for the financial position as on March 31, 2024.

4.6 Non-bank PPI issuer (authorised till October 11, 2017) shall comply with the minimum positive net-worth requirement of Rs.15 crore for the financial position as on September 30, 2021 (provisional balance sheet). This shall be reported to RBI, along with CA certificate in the enclosed format ([Annex-2](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_2.pdf)) and provisional balance sheet, by October 31, 2021 failing which they may not be permitted to carry out this business. Thereafter, the minimum positive net-worth of Rs.15 crore shall be maintained at all times. Till September 30, 2021, the existing PPI issuer shall continue to maintain the capital requirements applicable to it at the time of its authorisation.

4.7 Authorised non-bank PPI issuer shall submit a net-worth certificate every year in the enclosed format ([Annex-2](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_2.pdf)) to evidence compliance with the applicable net-worth requirement as per the audited balance sheet of the financial year within six months of completion of that financial year.

4.8 Newly incorporated non-bank entities that may not have an audited statement of financial accounts shall submit a certificate in the enclosed format ([Annex-2](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_2.pdf)) from their CA regarding the current net-worth along with provisional balance sheet.

4.9 Non-bank PPI issuer shall also be guided by [DPSS circular CO.DPSS.AUTH.No.S190/02.27.005/2021-22 dated June 14, 2021](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12114&Mode=0) (as amended from time to time) on Investment in entities from FATF non-compliant jurisdictions.

## 5. Authorisation process for non-banks

5.1 A non-bank entity desirous of issuing PPIs shall apply for authorisation in [Form A](https://rbidocs.rbi.org.in/rdocs/Forms/PDFs/PSSACRT130215.PDF) (available on RBI website [www.rbi.org.in](https://www.rbi.org.in)) as prescribed under Regulation 3(2) of the Payment and Settlement Systems Regulations, 2008 (PSS Regulations) along with the requisite application fees.

5.2 The application shall initially be screened by RBI to ensure prima facie eligibility of the applicant. The directors of the applicant entity shall submit a declaration in the enclosed format ([Annex-3](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_3.pdf)). RBI shall also check ‘fit and proper’ status of the applicant. Application of entities not meeting the eligibility criteria, or those that are incomplete / not in the prescribed form with all details, shall be returned without refund of the application fees.

5.3 In addition to the compliance with the applicable guidelines, RBI shall also apply checks, inter-alia, on certain essential aspects like customer service and efficiency, technical and other related requirements, safety and security aspects, etc., before granting in-principle approval to the applicants.

5.4 Subject to meeting the eligibility criteria and other conditions, the RBI shall issue an ‘in-principle’ approval, which shall be valid for a period of six months. The entity shall submit a satisfactory System Audit Report (SAR) to RBI within these six months, failing which the in-principle approval shall lapse automatically. SAR shall be accompanied by a certificate from the CA regarding compliance with the minimum positive net-worth. An entity can seek one-time extension for a maximum period of six months for submission of SAR by making a request in writing, to DPSS, CO, RBI, Mumbai, in advance with valid reasons. The RBI reserves the right to decline such a request for extension.

5.5 Subsequent to the issue of the in-principle approval, if any adverse features regarding the entity / promoters / group or business practices, etc., come to notice, RBI may impose additional conditions and if warranted, the in-principle approval may be withdrawn.

5.6 Pursuant to receipt of satisfactory SAR, net-worth certificate and due diligence, RBI shall grant final Certificate of Authorisation (CoA). Entities granted final authorisation shall commence business within six months from the grant of CoA failing which the authorisation shall lapse automatically. An entity can seek one-time extension for a maximum period of six months by making a request in writing, to DPSS, CO, RBI, Mumbai, in advance with valid reasons. RBI reserves the right to decline such a request for extension.

5.7 CoA shall be granted to all PSOs on a perpetual basis subject to the conditions stated in [DPSS circular DPSS.CO.AD.No.724/02.27.005/2020-21 dated December 4, 2020](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12000&Mode=0) (as amended from time to time).

5.8 Entities seeking renewal of authorisation shall apply in writing to DPSS, CO, RBI, Mumbai at least three months before the expiry of validity of CoA, failing which RBI reserves the right to decline the request for renewal.

5.9 Any proposed major change, such as changes in product features / process, structure or operation of the payment system, etc., shall be communicated with complete details to the Chief General Manager (CGM), DPSS, CO, RBI, Mumbai. RBI shall endeavour to reply within 15 working days after receipt of above communication at DPSS, CO, RBI, Mumbai.

5.10 Any takeover or acquisition of control or change in management of a non-bank entity shall be communicated to the CGM, DPSS, CO, RBI, Mumbai within 15 days with complete details, including ‘Declaration and Undertaking’ ([Annex-3](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_3.pdf)) by each of the new directors, if any. RBI shall examine the ‘fit and proper’ status of the management and, if required, may place suitable restrictions on such changes.

5.11 To inculcate discipline and encourage submission of applications by serious players as also for effective utilisation of regulatory resources, Cooling Period of one year has been introduced (vide [DPSS circular DPSS.CO.OD.No.753/06.08.005/2020-21 dated December 4, 2020](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12001&Mode=0), as updated from time to time) in the following situations –

- PPI issuer whose CoA is revoked or not-renewed for any reason; or

- CoA is voluntarily surrendered for any reason; or

- Application for authorisation has been rejected by RBI; or

- New entities that are set-up by promoters involved in any of the above categories; definition of promoters for the purpose, shall be as defined in the Companies Act, 2013.

In respect of entities whose application for authorisation is returned for any reason by RBI, condition of Cooling Period shall be invoked after giving the entity an additional opportunity to submit the application. During the Cooling Period, entities shall be prohibited from submission of applications for operating any payment system under the PSS Act.

## 6. Safeguards against money laundering provisions

6.1 The Know Your Customer (KYC) / Anti-Money Laundering (AML) / Combating Financing of Terrorism (CFT) guidelines issued by the Department of Regulation (DoR), RBI, in “[Master Direction – Know Your Customer Direction, 2016](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=11566)”, as updated from time to time, shall apply mutatis mutandis to all the entities issuing PPIs.

6.2 Provisions of Prevention of Money Laundering Act, 2002 (PMLA) and Rules framed thereunder, as amended from time to time, shall be applicable to PPI issuer.

6.3 PPI issuer shall maintain a log of all the transactions undertaken using the PPIs for at least ten years. This data shall be made available for scrutiny to RBI or any other agency / agencies as may be advised by RBI. The PPI issuer shall also file Suspicious Transaction Reports (STRs) to Financial Intelligence Unit-India (FIU-IND).

## 7. Issuance, loading and reloading of PPIs

7.1 All entities approved / authorised to issue PPIs by RBI are permitted to issue reloadable or non-reloadable PPIs depending upon the permissible type / category of PPIs as laid down in paragraph 9 and 10 of these Directions.

7.2 PPI issuer shall have a clear laid down policy, duly approved by its Board, for issuance of various types / categories of PPIs and all activities related thereto.

7.3 PPI issuer shall ensure that the name of the company which has received approval / authorisation for issuance and operating of PPIs, is prominently displayed along with the PPI brand name in all instances. PPI issuer shall also keep RBI informed regarding the brand names employed / to be employed for its products.

7.4 PPI issuer shall not pay any interest on PPI balances.

7.5 PPIs shall be permitted to be loaded / reloaded by cash, debit to a bank account, credit and debit cards, PPIs (as permitted from time to time) and other payment instruments issued by regulated entities in India and shall be in INR only.

7.6 Cash loading to PPIs shall be limited to Rs.50,000/- per month subject to overall limit of the PPI.

7.7 PPIs may be issued as cards, wallets, and in any such form / instrument which can be used to access the PPI and to use the amount therein. No PPI shall be issued in the form of paper vouchers.

7.8 Banks shall be permitted to load / reload PPIs through BCs subject to compliance with BC guidelines issued by RBI.

7.9 Banks and non-banks shall be permitted to load / reload PPIs through their authorised outlets or through their authorised / designated agents subject to following conditions:-

- Having a Board approved policy clearly laying down the framework for engaging agents;

- Carrying out proper due diligence of the persons appointed as authorised / designated agents;

- Being responsible as the principal for all acts of omission or commission of their authorised / designated agents, including safety and security aspects;

- Preserving records and confidentiality of customer information in their possession as well as in the possession of their authorised / designated agents;

- Monitoring regularly the activities of their authorised / designated agents and carrying out review of the performance of various agents engaged by them at least once in a year; and

- Ensuring adherence to applicable laws of the land, including KYC / AML / CFT norms as indicated in paragraph 6.

7.10 PPI issuer shall ensure that there is no co-mingling of funds originating from any other activity that they may be undertaking such as BC of bank/s, intermediary for payment aggregation, payment gateway, etc.

## 7.11 PPIs under co-branding arrangements

- The co-branding arrangement shall be as per the Board approved policy of the PPI issuer. The policy shall specifically address issues pertaining to the various risks associated with such an arrangement including reputation risk and the PPI issuer shall put in place suitable risk mitigation measures. The policy shall also clearly lay down the roles, responsibilities and obligations of each co-branding partner.

- The co-branding partner shall be a company incorporated in India under the Companies Act, 1956 / 2013. The co-branding partner can also be a Government department / ministry. In case the co-branding partner is a bank, the same shall be licensed by RBI.

- PPI issuer shall carry out due diligence of the co-branding partner to protect themselves against the reputation risk. In case of tie up with a financial entity, it may ensure that approval of co-branding partner’s regulator for entering into such arrangement is available.

- Instructions / Guidelines on KYC / AML / CFT (as indicated in paragraph 6) shall be adhered to in respect of all PPIs issued under the co-branding arrangement.

- PPI issuer shall be liable for all acts of the co-branding partner. The issuer shall also be responsible for all customer-related aspects of the PPIs.

- PPI issuer shall be permitted to co-brand such instruments with the name / logo of the company for whose customers / beneficiaries such co-branded instruments are to be issued.

- The name of PPI issuer shall be prominently visible on the payment instrument.

- In case of non-bank PPI issuer, where co-branding arrangement takes place between two non-bank PPI issuers, the agreement shall clearly indicate which partner is the PPI issuer.

- Non-bank PPI issuer desirous of issuing co-branded PPIs shall seek one time approval from DPSS, CO, RBI, Mumbai.

- In case of co-branding arrangements between a bank and non-bank entity, the bank shall be the PPI issuer. Role of the non-bank entity shall be limited to marketing / distribution of the PPIs or providing access to the PPI holder to services that are offered.

- In case of co-branding arrangement between two banks, the PPI issuing bank shall ensure compliance to above instructions.

- Bank PPI issuer shall also adhere to instructions contained in [circular DBR.No.FSD.BC.18/24.01.009/2015-16 dated July 1, 2015](https://www.rbi.org.in/Scripts/BS_ViewMasCirculardetails.aspx?id=9838), as amended from time to time.

7.12 There shall be no remittance without compliance to KYC requirements. The PPI issuer, including its agent/s, shall not create new PPIs every time for facilitating cash-based remittances to other PPIs / bank accounts. PPIs created for previous remittance by the same person shall be used.

## 8. Cross-border transactions

The use of INR denominated PPIs for cross-border transactions shall not be permitted except as under:

## 8.1 PPIs for cross-border outward transactions

- Full-KYC PPIs issued by banks having AD-I licence shall be permitted to be used in cross-border outward transactions (only for permissible current account transactions under FEMA viz. purchase of goods and services), subject to adherence to extant norms governing such transactions;

- PPIs shall not be used for any cross-border outward fund transfer and / or for making payments under Liberalised Remittances Scheme (LRS). Prefunding of online merchant’s account shall not be permitted using such Rupee denominated PPIs;

- PPI issuer shall enable the facility of cross-border outward transactions only on explicit request of the PPI holders and shall apply a per transaction limit not exceeding Rs.10,000/-, while per month limit shall not exceed Rs.50,000/- for such cross-border transactions;

- In case such PPIs are issued in card form, it shall be ensured that they are EMV Chip and PIN compliant; and

- Such PPIs may not be issued as a separate category of PPI.

## 8.2 PPIs for credit towards cross-border inward remittances

- Bank and non-bank PPI issuer, appointed as Indian agent of authorised overseas principals, shall be permitted to issue full-KYC PPIs to beneficiaries of inward remittances under the Money Transfer Services Scheme (MTSS) of RBI;

- Such PPIs shall be issued in adherence to extant norms under the MTSS Guidelines issued by Foreign Exchange Department (FED), RBI;

- Amounts only upto Rs.50,000/- from individual inward MTSS remittances shall be permitted to be loaded / reloaded in full-KYC PPIs issued to beneficiaries. Amount in excess of Rs.50,000/- shall be paid by credit to a bank account of the beneficiary. Full details of the transactions shall be maintained on record for scrutiny;

- Roles and responsibilities of PPI issuer shall be distinct from roles and responsibilities as Indian Agents under MTSS; and

- Such PPIs may not be issued as a separate category of PPI.

8.3 Foreign Exchange PPIs: Entities authorised under FEMA to issue foreign exchange denominated PPIs shall be outside the purview of this MD.

## 9. Types of PPIs

## 9.1 Small PPIs (or Minimum-detail PPIs)

## (i) PPIs upto Rs.10,000/- (with cash loading facility)

- Bank and non-banks shall be permitted to issue such PPIs after obtaining minimum details of the PPI holder;

- Minimum details shall necessarily include a mobile number verified with One Time Password (OTP) and a self-declaration of name and unique identity / identification number of any ‘mandatory document’ or ‘Officially Valid Document (OVD)’ or any such document with any name listed for this purpose in the Master Direction on KYC, as amended from time to time;

- Such PPIs shall be reloadable in nature;

- Amount loaded in such PPIs during any month shall not exceed Rs.10,000/- and the total amount loaded during the financial year shall not exceed Rs.1,20,000/-;

- Amount outstanding at any point of time in such PPIs shall not exceed Rs.10,000/-;

- Total amount debited from such PPIs during any month shall not exceed Rs.10,000/;

- These PPIs shall be used only for purchase of goods and services. Cash withdrawal or funds transfer from such PPIs shall not be permitted;

- There shall be no separate limit for purchase of goods and services using PPIs; PPI issuer may decide limit for these purposes within the overall PPI limit;

- These PPIs shall be converted into full-KYC PPIs (as defined in paragraph 9.2) within a period of 24 months from the date of issue of the PPI, failing which no further credit shall be allowed in such PPIs. However, the PPI holder shall be allowed to use the balance available in the PPI;

- This category of PPI shall not be issued to the same user in future using the same mobile number and same minimum details;

- PPI issuer shall give an option to close the PPI at any time. The closure proceeds can be transferred ‘back to source account’ (payment source from where the PPI was loaded). Alternatively, the closure proceeds can be transferred to a bank account after complying with KYC requirements of PPI holder; and

- The features of such PPIs shall be clearly communicated to the PPI holder by SMS / e-mail / any other means at the time of issuance of the PPI / before the first loading of funds.

## (ii) PPIs upto Rs.10,000/- (with no cash loading facility)

- Banks and non-banks shall be permitted to issue such PPIs after obtaining minimum details of the PPI holder;

- Minimum details shall necessarily include a mobile number verified with OTP and a self-declaration of name and unique identity / identification number of any ‘mandatory document’ or OVD or any such document with any name listed for this purpose in the Master Direction on KYC, as amended from time to time;

- Such PPIs shall be reloadable in nature. Loading / Reloading shall be from a bank account / credit card / full-KYC PPI;

- The amount loaded in such PPIs during any month shall not exceed Rs.10,000 and the total amount loaded during the financial year shall not exceed Rs.1,20,000;

- The amount outstanding at any point of time in such PPIs shall not exceed Rs.10,000;

- These PPIs shall be used only for purchase of goods and services. Cash withdrawal or funds transfer from such PPIs shall not be permitted;

- PPI issuer shall give an option to close the PPI at any time. The closure proceeds can be transferred ‘back to source account’ (payment source from where the PPI was loaded). Alternatively, the closure proceeds can be transferred to a bank account after complying with KYC requirements of PPI holder;

- The features of such PPIs shall be clearly communicated to the PPI holder by SMS / e-mail / any other means at the time of issuance of the PPI / before the first loading of funds; and

- The PPIs of paragraph 9.1 (i) existing as on December 24, 2019 can be converted to this type of PPI, if desired by the PPI holder.

## 9.2 Full-KYC PPIs

- Banks and non-banks shall be permitted to issue such PPIs after completing KYC of the PPI holder (as indicated in paragraph 6);

- The Video-based Customer Identification Process (V-CIP), as detailed in Department of Regulation’s Master Direction on KYC dated February 25, 2016 (as amended from time to time), can be used to open full-KYC PPIs as well as to convert Small PPIs of paragraph 9.1 into full-KYC PPIs;

- Such PPIs shall be reloadable in nature;

- The amount outstanding shall not exceed Rs.2,00,000/- at any point of time;

- The funds can be transferred ‘back to source account’ (payment source from where the PPI was loaded) or ‘own bank account of the PPI holder’ (duly verified by the PPI issuer). However, PPI issuer shall set the limits considering the risk profile of the PPI holders, other operational risks, etc.;

- PPI issuer shall provide the facility of ‘pre-registered beneficiaries’ whereby the PPI holder can register the beneficiaries by providing their bank account details, details of PPIs issued by same issuer (or different issuer as and when permitted), etc.;

- In case of such pre-registered beneficiaries, the funds transfer limit shall not exceed Rs.2,00,000/- per month per beneficiary. PPI issuer shall set the limits within this ceiling considering the risk profile of the PPI holders, other operational risks, etc.;

- Funds transfer limits for all other cases shall be restricted to Rs.10,000/- per month;

- Funds transfer from such PPIs shall also be permitted to other PPIs, debit cards and credit cards as per the limits given above;

- There is no separate limit on purchase of goods and services using PPIs and PPI issuer may decide limit for these purposes within the overall PPI limit;

- PPI issuer shall clearly indicate these limits to the PPI holders and provide necessary options to PPI holders to set their own fund transfer limits;

- PPI issuer shall also give an option to close the PPI and transfer the balance as per the applicable limits of this type of PPI. For this purpose, the issuer shall provide an option, including at the time of issuing the PPI, to the holder to provide details of pre-designated bank account or other PPIs of same issuer (or other issuer as and when permitted) to which the balance amount available in the PPI shall be transferred in the event of closure of PPI, expiry of validity period of such PPIs, etc.;

- In case of bank issued PPIs, cash withdrawal shall be permitted. However, cash withdrawal at PoS devices shall be subjected to a limit of Rs.2,000/- per transaction within an overall monthly limit of Rs.10,000/- across all locations (Tier 1 to 6 centres), subject to conditions stipulated in [RBI circular DPSS.CO.PD.No.449/02.14.003/2015-16 dated August 27, 2015](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=10004&Mode=0);

- In case of non-bank issued PPIs, cash withdrawal shall be permitted upto a maximum limit of Rs.2,000/- per transaction within an overall monthly limit of Rs.10,000/- per PPI across all channels (agents, ATMs, PoS devices, etc.); and

- Features of such PPIs shall be clearly communicated to the PPI holder by SMS / e-mail / any other means at the time of issuance of the PPI / before the first loading of funds.

## 10. Specific categories of PPIs

Banks and non-banks shall not issue PPIs of any other category except as permitted under the following categories:

## 10.1 Gift PPIs

- Maximum value of each such prepaid gift instrument shall not exceed Rs.10,000/-;

- Such instrument shall not be reloadable;

- Cash-out or funds transfer shall not be permitted for such instrument. However, the funds may be transferred ‘back to source account’ (account from where Gift PPI was loaded) after receiving consent of the PPI holder;

- KYC (as indicated in paragraph 6) details of the purchaser of such instrument shall be maintained by the PPI issuer. Separate KYC shall not be required for customers who are issued such instrument against debit to their bank accounts and / or credit cards in India;

- PPI issuer shall adopt a risk-based approach, duly approved by its Board, in deciding number of such instruments which can be issued to a customer, transaction limits, etc.;

- These PPIs shall be revalidated (including through issuance of new instrument) as and when requested by the PPI holder;

- Provisions of paragraph 13 on validity and redemption, as applicable, shall be adhered to; and

- Features of such PPIs shall be clearly communicated to the PPI holder by SMS / e-mail / any other means at the time of issuance of the PPI / before the first loading of funds.

## 10.2 PPIs for Mass Transit Systems (PPI-MTS)

- Banks / non-banks are permitted to issue such PPIs;

- Such PPIs shall contain the Automated Fare Collection application related to transit services, toll collection and parking;

- Such PPIs shall be enabled only for payments across various modes of public transport such as metro, buses, rail, & waterways, tolls and parking;

- These PPIs can be issued without KYC verification of the holders;

- These PPI can be reloadable in nature;

- The amount outstanding, in such PPIs shall not exceed Rs.3,000/- at any point of time;

- These PPIs can have perpetual validity, i.e., the provisions of validity and redemption given in Section 13 of this MD shall not apply to PPI-MTS; and

- Cash-withdrawal, refund or funds transfer shall not be permitted in such PPIs.

## 10.3 PPIs to Foreign Nationals / Non-Resident Indians (NRIs) visiting India

- Banks / Non-banks permitted to issue PPIs can issue INR denominated full-KYC PPIs to foreign nationals / NRIs visiting India (to start with, this facility will be extended to travellers from the G-20 countries, arriving at select international airports). Such PPIs can also be issued in co-branding arrangement with entities authorised to deal in Foreign Exchange under FEMA;

- The PPIs shall be issued after physical verification of Passport and Visa of the customers at the point of issuance. The PPI issuers shall ensure that such information and record thereof are maintained with them;

- The PPIs can be issued in the form of wallets linked to UPI and can be used for merchant payments (P2M) only;

- Loading / Reloading of such PPIs shall be against receipt of foreign exchange by cash or through any payment instrument;

- The conversion to Indian Rupee shall be carried out only by entities authorised to deal in Foreign Exchange under FEMA;

- The amount outstanding at any point of time in such PPIs shall not exceed the limit applicable on full-KYC PPIs;

- Provisions of paragraph 13 on validity and redemption, as applicable, shall be adhered to. The unutilised balances in such PPIs can be encashed in foreign currency or transferred ‘back to source’ (payment source from where the PPI was loaded), in compliance with foreign exchange regulations;

## 11. Interoperability

11.1 Interoperability is the technical compatibility that enables a payment system to be used in conjunction with other payment systems.

11.2 PPI issuer shall be guided by the technical specifications / standards / requirements for achieving interoperability through UPI and card networks as per the requirements of National Payments Corporation of India (NPCI) and the respective card networks. NPCI and card networks shall facilitate participation by PPI issuer in UPI and card networks.

11.3 PPI issuer shall have a policy for achieving PPI interoperability.

## 11.4 Requirements for achieving interoperability: Common to wallets and cards

11.4.1 Where PPIs are issued in the form of wallets, interoperability across PPIs shall be enabled through UPI.

11.4.2 Where PPIs are issued in the form of cards (physical or virtual), the cards shall be affiliated to the authorised card networks.

11.4.3 PPI-MTS shall remain exempted from interoperability, while Gift PPI issuer (both banks and non-banks) have the option to offer interoperability.

11.4.4 The interoperability shall be facilitated to all KYC-compliant PPIs and entire acceptance infrastructure. It shall be mandatory for PPI issuer to give the holders of full-KYC PPIs (KYC-compliant PPIs) interoperability through authorised card networks (for PPIs in the form of cards) and UPI (for PPIs in the form of wallets).

11.4.5 Interoperability shall be mandatory on the acceptance side as well. QR codes in all modes shall be interoperable by March 31, 2022 vide [RBI circular DPSS.CO.PD.No.497/02.14.003/2020-21 dated October 22, 2020](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11987&Mode=0). For other modes of acceptance, as also for issuance, the interoperability shall be achieved by March 31, 2022. Once a non-bank PPI entity becomes interoperable (on both issuing and acquiring side simultaneously), the entire merchant base, including those acquired by the banks, shall be accessible through the card networks and UPI.

11.4.6 Technical requirements : PPI issuer shall adhere to all the requirements of card networks / UPI including membership type and criteria, merchant on-boarding, adherence to various standards, rules and regulations applicable to the specific payment system such as technical requirements, certifications and audit requirements, governance, etc.

11.4.7 Reconciliation, customer protection and grievance redressal :

- PPI issuer shall ensure adherence to all guidelines / requirements of card networks / UPI in terms of reconciliation of positions at daily / weekly / monthly or more frequent basis, as the case may be.

- PPI issuer shall adhere to all dispute resolution and customer grievance redressal mechanisms as prescribed by the card networks / NPCI.

## 11.5 Requirements for achieving interoperability through card networks

11.5.1 Card networks are allowed to onboard PPI issuer to join their network. Non-bank PPI issuer is permitted to participate as member / associate member of authorised card networks.

11.5.2 Settlement : For the purpose of settlement, a non-bank PPI issuer can participate directly or through a sponsor bank arrangement as the case may be. Non-bank PPI issuer shall adhere to the requirements of respective card network’s settlement system.

11.5.3 Safety and security :

- Banks and non-banks shall ensure that all new PPIs issued in the form of cards are EMV Chip and PIN compliant.

- Banks and non-banks shall ensure that all reissuance / renewal of PPIs in the form of cards are EMV Chip and PIN compliant.

- Gift PPIs may continue to be issued with or without EMV Chip and PIN enablement.

## 11.6 Requirements for achieving interoperability through UPI

11.6.1 PPI issuer shall facilitate all basic / standard features of interoperability of UPI.

11.6.2 PPI issuer shall act as Payment System Providers (PSP) in UPI. NPCI shall issue handle to the PPI issuer as per its policy / guidelines taking risk management aspects into consideration. Since *99# USSD is part of UPI, non-bank PPI issuer are also allowed to participate in the same.

11.6.3 A PPI issuer shall enable holders of only its full-KYC PPIs to make UPI payments by linking its customer PPIs to its UPI handle. UPI transactions from PPI on the issuer’s application shall be authenticated using the customer’s existing PPI credentials. Such a transaction will, thus, be pre-approved before it reaches the UPI system. A PPI issuer, in its capacity as a PSP, shall not on-board customers of any bank or any other PPI issuer.

11.6.4 A PPI issuer may also facilitate discovery of its full-KYC PPIs on third-party UPI mobile applications, who, in turn shall enable such PPIs to be linked to their PSP handle/s. Such UPI transactions, from PPIs using third party UPI applications, shall be authenticated using the UPI credentials.

11.6.5 Settlement: For the purposes of settlement, a non-bank PPI issuer shall participate through a sponsor bank. Non-bank PPI issuer shall adhere to the requirements of sponsor bank arrangement in UPI as also meet all requirements of NPCI in this regard.

## 12. Deployment of money collected

12.1 To ensure timely settlement, the non-bank PPI issuer shall invest the money collected against issuance of PPIs only as provided herein.

12.2 For the schemes operated by banks, the outstanding balance shall be part of the ‘net demand and time liabilities’ for the purpose of maintenance of reserve requirements. This position will be computed on the basis of balances appearing in the books of the bank as on the date of reporting.

12.3 Non-bank PPI issuer is required to maintain the outstanding balance in an escrow account with any scheduled commercial bank. An additional escrow account may be maintained with a different scheduled commercial bank at the discretion of the PPI issuer. For the purpose of maintenance of escrow account, payment system operated by the non-bank PPI issuer for issuance of PPIs shall be deemed to be ‘designated payment system’ under Section 23A of the PSS Act. Non-bank PPI issuer that is member of Centralised Payment Systems operated by RBI shall maintain a Current Account with RBI. Maintenance of escrow balance shall be subject to the following conditions:-

(i) In case there is a need to shift the escrow account from one bank to another, the same shall be effected in a time-bound manner without unduly impacting the payment cycle to merchants. Migration shall be completed in the minimum possible time with prior intimation to RBI.

(ii) The balance in the escrow account shall not, at the end of the day, be lower than the value of outstanding PPIs and payments due to merchants. While as far as possible PPI issuer shall ensure immediate credit of funds to escrow on issue, load / reload of PPIs to the PPI holders, under no circumstance such credit to escrow account shall be later than the close of business day (the day on which the PPI has been issued, loaded / reloaded). This shall be monitored by the non-bank PPI issuer on daily basis and any shortfall shall be immediately reported to the respective Regional Office of DPSS, RBI.

(iii) Only the following debits and credits shall be permitted in the escrow account; in case where an additional escrow account is being maintained, credit and debit from one escrow account to the other shall also be permitted. However, inter-escrow transfers shall be avoided as far as possible and if resorted to, auditor’s certification shall clearly mention such transactions. The balance in Current Account with the RBI shall not be reckoned for the purpose of maintenance of daily balance in escrow accounts.

## Credits

a. Payments received towards issue, load / reload of PPIs, including at agent locations;

b. Refunds received for failed / disputed / returned / cancelled transactions; and

c. Payments received from sponsor bank towards settlement obligations from participation in interoperable payment systems, as permitted by RBI from time to time;

d. Transfers from Current Account maintained with RBI.

## Debits

e. Payments to various merchants / service providers towards reimbursement of claims received from them;

f. Payment to sponsor bank for processing funds transfer instructions received from PPI holders as permitted by RBI from time to time;

g. Payments made to sponsor bank towards settlement obligations from participation in interoperable payment systems, as permitted by RBI from time to time;

h. Transfers to Current Account maintained with RBI.

i. Payment towards applicable Government taxes (received along with PPI sale / reload amount from the buyers);

j. Refunds towards cancellation of transactions in a PPI in case of PPIs loaded / reloaded erroneously or through fraudulent means (on establishment of erroneous transfer / fraud). The funds shall be credited back to the same source from where these were received. These funds are not to be forfeited till the disposal of the case;

k. Any other payment due to the PPI issuer in the normal course of operating PPI business (for instance, service charges, forfeited amount, commissions, etc.); and

l. Any other debit as directed by the regulator / courts / law enforcement agencies.

Note: (1) The payment towards service charges, commission and forfeited amount shall be at pre-determined rates / frequency. Such transfers shall only be effected to a designated bank account of the PPI issuer as indicated in the agreement with the bank where escrow account is maintained. (2) All these provisions shall be part of Service Level Agreement that will be signed between the PPI issuer and the bank maintaining escrow account.

(iv) The agreement between the PPI issuer and the bank maintaining escrow account shall include a clause enabling the bank to use the money in the escrow account only for purposes mentioned in these Directions.

(v) Settlement of funds with merchants shall not be co-mingled with other business, if any, handled by the PPI issuer.

(vi) No interest shall be payable by the bank on such balances, except as indicated in paragraph 12.4 below.

(vii) PPI issuer shall be required to submit the list of merchants acquired by them to the bank and update the same from time to time. The bank shall be required to ensure that payments are made only to eligible merchants / purposes. There shall be an exclusive clause in the agreement signed between the PPI issuer and bank maintaining escrow account towards usage of balance in escrow account only for the purposes mentioned above.

(viii) With the growing acceptance of PPIs in e-commerce payments, including in digital market places, the payment mechanism is often facilitated using the services of payment aggregators / payment gateways. In such a scenario, the emerging practice observed is that the PPI issuer has the necessary agreements with the digital market place and / or the payment aggregator / gateway rather than the individual merchants who are accepting the PPIs as a payment instrument. In view of the above, PPI issuer shall obtain an undertaking from the digital market place and / or payment aggregator / gateway that the payments made by the issuer are used for onward payments to the respective merchants. Such an undertaking shall be submitted by the PPI issuer to the bank maintaining the escrow account.

(ix) A certificate (format enclosed [Annex-5](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_5.pdf)) signed by the auditor(s), shall be submitted by the authorised entities to the respective Regional Office of DPSS, RBI on a quarterly basis certifying that the entity has been maintaining adequate balance(s) in the escrow account(s) to cover outstanding value of PPIs issued and payments due to merchants. In case, an additional escrow account is being maintained, it shall be ensured that balances in both accounts are considered for the above certification. This shall also be indicated in the certificate. The same auditor shall be employed to audit both escrow accounts. The certificate shall be submitted within a fortnight from the end of quarter to which it pertains. Entities shall also submit an annual certificate ([Annex-5](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_5.pdf)), signed by the auditor, coinciding with accounting year of the entity to RBI.

(x) Adequate records indicating the daily position of the value of instruments outstanding and payments due to merchants vis-à-vis balances maintained with the banks in the escrow accounts shall be made available for scrutiny to RBI or the bank where the account is maintained on demand.

12.4 As an exception to paragraph 12.3 (vi), the non-bank PPI issuer can enter into an agreement with the bank maintaining the escrow account, to transfer "core portion" of the amount, in the escrow account to a separate account on which interest is payable, subject to the following:-

- The bank shall satisfy itself that the amount deposited represents the "core portion" after due verification of necessary documents.

- The amount shall be linked to the escrow account, i.e. the amounts held in the interest bearing account shall be available to the bank, to meet payment requirements of the entity, in case of any shortfall in the escrow account.

- This facility is permissible to entities who have been in business for at least one year (26 fortnights) and whose accounts have been duly audited for the full accounting year.

- No loan is permissible against such deposits. Banks shall not issue any deposit receipts or mark any lien on the amount held in such form of deposits.

- Core portion shall be calculated separately for each of the escrow accounts and will remain linked to the respective escrow account. Escrow balance and core portion maintained shall be clearly disclosed in the auditors’ certificates submitted to RBI on quarterly and annual basis.

Note: For the purpose of these Directions, "Core Portion" shall be computed as under:-

Step 1: Compute lowest daily outstanding balance (LB) on a fortnightly (FN) basis, for one year (26 fortnights) from the preceding month.

Step 2: Calculate the average of the lowest fortnightly outstanding balances [(LB1 of FN1+ LB2 of FN2+ ........+ LB26 of FN26) divided by26].

Step 3: The average balance so computed represents the "Core Portion" eligible to earn interest.

## 13. Validity and redemption

13.1 All PPIs issued in the country shall have a minimum validity period of one year from the date of last loading / reloading in the PPI. PPIs can be issued with a longer validity as well. In case of PPIs issued in the form of card (with validity period mentioned on the card), the customer shall have the option to seek replacement of the card.

13.2 PPI issuer shall caution the PPI holder at reasonable intervals, during the 45 days’ period prior to expiry of the validity period of the PPI. The caution advice shall be sent by SMS / e-mail / any other means in the language preferred by the holder indicated at the time of issuance of the PPI.

13.3 Non-bank PPI issuer cannot transfer the outstanding balance to its Profit & Loss account for at least three years from the expiry date of PPI. In case the PPI holder approaches the PPI issuer for refund of such amount, at any time after the expiry date of PPI, then the same shall be paid to the PPI holder in a bank account.

13.4 Bank issuing PPIs shall be guided by the instructions on Depositor Education and Awareness Fund (DEA Fund) issued by Department of Banking Regulation, RBI, vide, [circular DBOD.No.DEAF Cell.BC.101/30.01.002/2013-14 dated March 21, 2014](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=8780&Mode=0), as amended from time to time.

13.5 The PPI Issuer shall clearly indicate the expiry period of the PPI to the customer at the time of issuance of PPIs. Such information shall be clearly enunciated in the terms and conditions of sale of PPI. Where applicable, it shall also be clearly outlined on the website / mobile application of the PPI issuer.

13.6 PPIs with no financial transaction for a consecutive period of one year shall be made inactive by the PPI issuer after sending a notice to the PPI holder/s. These can be reactivated only after validation and applicable due diligence. These PPIs shall be reported to RBI separately.

13.7 The holders of PPIs shall be permitted to redeem the outstanding balance in the PPI, if for any reason the scheme is being wound-up or is directed by RBI to be discontinued.

## 14. Transactions limits

14.1 The PPI holder is allowed to use the PPI for purposes within the overall PPI limit applicable. PPI issuer shall decide on limits considering the risk perception of the holders as per its risk management policy.

14.2 All financial limits indicated against each type / category of the PPI shall be strictly adhered to.

## 14.3 Handling refunds

- Refunds in case of failed / returned / rejected / cancelled transactions shall be applied to the respective PPI immediately, to the extent that payment was made initially by debit to the PPI, even if such application of funds results in exceeding the limits prescribed for that type / category of PPI.

- However, refunds in case of failed / returned / rejected / cancelled transactions using any other payment instrument shall not be credited to PPI.

- PPI issuer shall be required to maintain complete details of such returns / refunds, etc., and be in readiness to provide them as and when called for.

- Further, PPIs issuer shall also put in place necessary systems that enable them to monitor frequent instances of refunds taking in place in specific PPIs and be in a position to substantiate with proof for audit / scrutiny purposes.

## 15. Security, fraud prevention and risk management framework

15.1 A strong risk management system is necessary for PPI issuer to meet challenges of fraud and ensure customer protection. PPI issuer shall put in place adequate information and data security infrastructure and systems for prevention and detection of frauds.

15.2 PPI issuer shall put in place Board approved Information Security policy for the safety and security of the payment systems operated by it, and implement security measures in accordance with this policy to mitigate identified risks. The PPI issuer shall review security measures (a) on on-going basis but at least once a year, (b) after any security incident or breach, and (c) before / after a major change to its infrastructure or procedures.

15.3 PPI issuer shall ensure that the following framework is put in place to address the safety and security concerns, and for risk mitigation and fraud prevention:

- In case of wallets, PPI issuer shall ensure that if same login is provided for the PPI and other services offered by them, the same shall be clearly informed to the customer by SMS or email or any other means. The option to logout from the website / mobile account shall be provided prominently.

- Issuer shall put in place appropriate mechanisms to restrict multiple invalid attempts to login / access to the PPI, inactivity, timeout features, etc.

- Issuer shall introduce a system where all wallet transactions involving debit to the wallet, including cash withdrawal transactions, shall be permitted only by validation through a Two Factor Authentication (2FA).

- The Additional Factor of Authentication (AFA) requirements for PPI Cards (physical or virtual) shall be same as required for debit cards.

- 2FA / AFA is not mandatory for PPIs issued under PPI-MTS and gift PPIs.

- The transactions undertaken using PPIs through National Electronic Toll Collection (NETC) system can be performed as per the instructions given in [DPSS circular DPSS.CO.PD.No.1227/02.31.001/2019-20 dated December 30, 2019](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11769&Mode=0), as amended from time to time.

- Processing of e-mandate for transactions undertaken using PPIs (cards and wallets) shall be performed, as per the instructions contained in [DPSS circular DPSS.CO.PD.No.447/02.14.003/2019-20 dated August 21, 2019](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11668&Mode=0), as amended from time to time.

- Issuer shall provide customer induced options for fixing a cap on number of transactions and transaction value for different types of transactions / beneficiaries. Customers shall be allowed to change the caps, with additional authentication and validation.

- Issuer shall put in place a limit on the number of beneficiaries that may be added in a day per PPI.

- Issuer shall introduce a system of alert when a beneficiary is added.

- Issuer shall put in place suitable cooling period for funds transfer and cash withdrawal upon opening the PPI or loading / reloading of funds into the PPI or after adding a beneficiary so as to mitigate the fraudulent use of PPIs.

- Issuer shall put in place a mechanism to send alerts when transactions are done using the PPIs. In addition to the debit or credit amount intimation, the alert shall also indicate the balance available / remaining in the PPI after completion of the said transaction. For transactions undertaken in offline mode, as allowed from time to time, the transaction alert shall be sent as soon as the details of transaction are received by the PPI issuer. There is no compulsion to send separate alert for each transaction; however, details of each transaction shall be adequately conveyed as soon as such information reaches the PPI issuer.

- Issuer shall put in place mechanism for velocity check on the number of transactions effected in a PPI per day / per beneficiary.

- Issuer shall also put in place suitable mechanism to prevent, detect and restrict occurrence of fraudulent transactions including loading / reloading funds into the PPI.

- Issuer shall put in place suitable internal and external escalation mechanisms in case of suspicious operations, besides alerting the customer in case of such transactions.

15.4 The requirements prescribed here are minimum and the entities may deploy additional checks and balances, as considered appropriate.

15.5 PPI issuer shall put in place centralised database / management information system (MIS) to prevent multiple purchase of PPIs at different locations, leading to circumvention of limits, if any, prescribed for their issuance. In case of full-KYC PPIs issued by scheduled commercial banks for government departments, the limit of Rs.2,00,000/- shall be for each PPI, provided the PPIs are issued for expenses of the concerned government department and the loading is from the bank account of the government department.

15.6 Where direct interface is provided to its authorised / designated agents, PPI issuer shall ensure that compliance to regulatory requirements is strictly adhered to by these systems also.

15.7 PPI issuer shall establish a mechanism for monitoring, handling and follow-up of cyber security incidents and cyber security breaches. The same shall be reported immediately to DPSS, CO, RBI, Mumbai. It shall also be reported to CERT-IN as per the details notified by CERT-IN.

15.8 PPI issuer shall also be guided by the following circulars:

- [DPSS.CO.PD No.1343/02.14.003/2019-20 dated January 15, 2020](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11788&Mode=0) (as amended from time to time) on ‘Enhancing Security of Card Transactions’. This circular, inter alia, gives the facility to card holders to switch on / off and set / modify the transaction limits across multiple channels.

- [DPSS.CO.OD.No.1934/06.08.005/2019-20 dated June 22, 2020](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11917&Mode=0) (as amended from time to time) on Increasing Instances of Payment Frauds – Enhancing Public Awareness Campaigns Through Multiple Channels.

- [CO.DPSS.POLC.No.S-384/02.32.001/2021-2022 dated August 03, 2021](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12136&Mode=0) (as amended from time to time) on Framework for Outsourcing of Payment and Settlement-related Activities by PSOs. The bank PPI issuer shall be guided by the outsourcing related instructions issued by their regulatory and supervisory departments.

## 16. Customer protection and grievance redressal framework

16.1 PPI issuer shall disclose all important terms and conditions in clear and simple language (preferably in English, Hindi and the local language) to the holders while issuing the instruments. These disclosures shall include:

- All charges and fees associated with the use of the instrument; and

- The expiry period and the terms and conditions pertaining to expiration of the instrument.

16.2 PPI issuer shall put in place a formal, publicly disclosed customer grievance redressal framework, including designating a nodal officer to handle the customer complaints / grievances, the escalation matrix and turn-around-times for complaint resolution. The complaint facility, if made available on website / mobile, shall be clear and easily accessible. The framework shall include, at the minimum, the following:

- PPI issuer shall disseminate the information of customer protection and grievance redressal policy in simple language (preferably in English, Hindi and the local language).

- PPI issuer shall clearly indicate the customer care contact details, including details of nodal officials for grievance redressal (telephone numbers, email address, postal address, etc.) on website, mobile wallet apps, and cards.

- PPI issuer’s agents shall display proper signage of the PPI Issuer and the customer care contact details as at (b) above.

- PPI issuer shall provide specific complaint numbers for the complaints lodged along with the facility to track the status of the complaint by the customer.

- PPI issuer shall initiate action to resolve any customer complaint / grievance expeditiously, preferably within 48 hours and endeavour to resolve the same not later than 30 days from the date of receipt of such complaint / grievance.

- PPI issuer shall display the detailed list of its authorised / designated agents (name, agent ID, address, contact details, etc.) on the website / mobile app.

16.3 PPI issuer shall create sufficient awareness and educate customers in the secure use of the PPIs, including the need for keeping passwords confidential, procedure to be followed in case of loss or theft of card or authentication data or if any fraud / abuse is detected, etc.

16.4 PPI issuer shall provide an option for the PPI holders to generate / receive account statements for at least past 6 months. The account statement shall, at the minimum, provide details such as date of transaction, debit / credit amount, net balance and description of transaction. Additionally, the PPI issuer shall provide transaction history for at least 10 transactions.

16.5 In case of PPIs issued by banks and non-banks, customers shall have recourse to the [Reserve Bank - Integrated Ombudsman Scheme, 2021](https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=52549) (as amended from time to time) for grievance redressal.

16.6 Non-bank PPI issuer shall report regarding the receipt of complaints and action taken status thereon in the enclosed format ([Annex-6](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_6.pdf)) on a Quarterly basis by the 10th of the following month to the respective Regional Office of DPSS, RBI. Banks shall submit the same report to DPSS, Mumbai Regional Office, RBI.

16.7 PPI issuer shall ensure transparency in pricing and the charge structure as under:

- Ensure uniformity in charges at agent level.

- Disclosure of charges for various types of transactions on its website, mobile app, agent locations, etc.

- Specific agreements with agents prohibiting them from charging any fee to the customers directly for services rendered by them on behalf of the PPI issuer.

- Require each retail outlet / sub-agent to post a signage indicating their status as service providers for the PPI issuer and the fees for all services available at the outlet.

- The amount collected from the customer shall be acknowledged by issuing a receipt (printed or electronic) on behalf of the PPI issuer.

16.8 PPI issuer shall be responsible for addressing all customer service aspects related to all PPIs (including co-branded PPIs) issued by them as well as their agents.

16.9 PPI issuer shall also display Frequently Asked Questions (FAQs) on its website / mobile app related to the PPIs.

16.10 PPI issuer shall also be guided by the following DPSS circulars:

- Harmonisation of Turn Around Time (TAT) and customer compensation for failed transactions using authorised Payment Systems issued vide [DPSS circular DPSS.CO.PD No.629/02.01.014/2019-20 dated September 20, 2019](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11693&Mode=0) (as amended from time to time);

- Online Dispute Resolution (ODR) system for resolving customer disputes and grievances pertaining to digital payments, using a system-driven and rule-based mechanism with zero or minimal manual intervention, issued vide [DPSS circular DPSS.CO.PD No.116/02.12.004/2020-21 dated August 6, 2020](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11946&Mode=0) (as amended from time to time).

## 17. Limiting liability of customers in unauthorised electronic payment transactions in PPIs issued by banks and non-banks

17.1 Bank PPI issuer shall continue to be guided by [RBI circulars DBR.No.Leg.BC.78/09.07.005/2017-18 dated July 6, 2017](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11040&Mode=0) or [DCBR.BPD.(PCB/RCB). Cir.No.06/12.05.001/2017-18 dated December 14, 2017](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11188&Mode=0), as applicable on Customer Protection – Limiting Liability of Customers in Unauthorised Electronic Banking Transactions.

17.2 Non-bank PPI issuer, shall adhere to the following criteria for determining the customers’ liability in unauthorised electronic payment transactions resulting in debit to its PPIs. PPIs issued under the arrangement of PPI-MTS as per paragraph 10.2 will be outside the purview of these paragraphs except for the cases of contributory fraud / negligence / deficiency on the part of the PPI-MTS issuer.

17.3 For the purpose of this MD, electronic payment transactions have been divided into two categories:

- Remote / Online payment transactions : Transactions that do not require physical PPIs to be presented at the point of transactions e.g. wallets, card not present (CNP) transactions, etc.; and

- Face-to-face / Proximity payment transactions : Transactions that require physical PPIs to be present at the point of transactions e.g. transactions at ATMs, PoS devices, etc.

17.4 Reporting of unauthorised payment transactions by customers to the non-bank PPI issuer:

- Non-bank PPI issuer shall ensure that its customers mandatorily register for SMS alerts and wherever available also register for e-mail alerts, for electronic payment transactions.

- The SMS alert for any payment transaction in the account shall mandatorily be sent to the customers and e-mail alert may additionally be sent, wherever registered. The transaction alert should have a contact number and / or e-mail id on which a customer can report unauthorised transactions or notify the objection.

- Customers shall be advised to notify the non-bank PPI issuer of any unauthorised electronic payment transaction at the earliest and, shall also be informed that longer the time taken to notify the non-bank PPI issuer, higher will be the risk of loss to the non-bank PPI issuer / customer.

- To facilitate this, non-bank PPI issuer shall provide customers with 24x7 access via website / SMS / e-mail / a dedicated toll-free helpline for reporting unauthorised transactions that have taken place and / or loss or theft of the PPI.

- Further, a direct link for lodging of complaints, with specific option to report unauthorised electronic payment transactions shall be provided by non-bank PPI issuer on mobile app / home page of its website / any other evolving acceptance mode.

- The loss / fraud reporting system so established shall also ensure that immediate response (including auto response) is sent to the customers acknowledging the complaint along with the registered complaint number. The communication systems used by non-bank PPI issuer to send alerts and receive their responses thereto shall record time and date of delivery of the message and receipt of customer’s response, if any. This shall be important in determining the extent of a customer’s liability. On receipt of report of an unauthorised payment transaction from the customer, non-bank PPI issuer shall take immediate action to prevent further unauthorised payment transactions in the PPI.

17.5 A customer’s liability arising out of an unauthorised payment transaction will be limited to:

| S. No. | Particulars | Maximum Liability of Customer |
| --- | --- | --- |
| (a) | Contributory fraud / negligence / deficiency on the part of the non-bank PPI issuer, including PPI-MTS issuer (irrespective of whether or not the transaction is reported by the customer) | Zero |
| (b) | Third party breach where the deficiency lies neither with the non-bank PPI issuer nor with the customer but lies elsewhere in the system, and the customer notifies the non-bank PPI issuer regarding the unauthorised payment transaction. The per transaction customer liability in such cases will depend on the number of days lapsed between the receipt of transaction communication by the customer from the non-bank PPI issuer and the reporting of unauthorised transaction by the customer to the non-bank PPI issuer - |  |
| i. Within three days [#] | Zero |  |
| ii. Within four to seven days [#] | Transaction value or ₹10,000/- per transaction, whichever is lower |  |
| iii. Beyond seven days [#] | As per the Board approved policy of the non-bank PPI issuer |  |
| (c) | In cases where the loss is due to negligence by a customer, such as where he / she has shared the payment credentials, the customer will bear the entire loss until he / she reports the unauthorised transaction to the non-bank PPI issuer. Any loss occurring after the reporting of the unauthorised transaction shall be borne by the non-bank PPI issuer. |  |
| (d) | Non-bank PPI issuer may also, at its discretion, decide to waive off any customer liability in case of unauthorised electronic payment transactions even in cases of customer negligence. |  |
| # The number of days mentioned above shall be counted excluding the date of receiving the communication from the non-bank PPI issuer. |  |  |

17.6 The above shall be clearly communicated to all PPI holders.

17.7 On being notified by the customer, the non-bank PPI issuer shall credit (notional reversal / shadow reversal) the amount involved in the unauthorised electronic payment transaction to the customer’s PPI within 10 days from the date of such notification by the customer (without waiting for settlement of insurance claim, if any), even if such reversal breaches the maximum permissible limit applicable to that type / category of PPI. The credit shall be value-dated to be as of the date of the unauthorised transaction.

17.8 Non-bank PPI issuer shall ensure that a complaint is resolved and liability of the customer, if any, established within such time, as may be specified in the non-bank PPI issuer’s Board approved policy, but not exceeding 90 days from the date of receipt of the complaint, and the customer is compensated as per provisions of paragraph 17.5 above. In case the non-bank PPI issuer is unable to resolve the complaint or determine the customer liability, if any, within 90 days, the amount as prescribed in paragraph 17.5 shall be paid to the customer, irrespective of whether the negligence is on the part of customer or otherwise.

17.9 Taking into account the risks arising out of unauthorised debits to PPIs owing to customer negligence / non-bank PPI issuer negligence / system frauds / third party breaches, non-bank PPI issuer needs to clearly define the rights and obligations of customers in case of unauthorised payment transactions in specified scenarios. Non-bank PPI issuer shall formulate / revise its customer relations policy, with approval of its Board, to cover aspects of customer protection, including the mechanism of creating customer awareness on the risks and responsibilities involved in electronic payment transactions and customer liability in such cases of unauthorised electronic payment transactions. The policy must be transparent, non-discriminatory and should stipulate the mechanism of compensating the customers for the unauthorised electronic payment transactions and also prescribe the timelines for effecting such compensation. Non-bank PPI issuer shall provide the details of its Board approved policy in regard to customers’ liability formulated in pursuance of the provisions of these directions, to all customers at the time of issuing the PPI. Non-bank PPI issuer shall display its Board approved policy, along with the details of grievance handling / escalation procedure, in public domain / website / app for wider dissemination.

17.10 The burden of proving customer liability in case of unauthorised electronic payment transactions shall lie on the non-bank PPI issuer.

17.11 Non-bank PPI issuer shall put in place a suitable mechanism and structure for reporting of the customer liability cases to the Board or one of its Committees. The reporting shall, inter-alia, include volume / number of cases and the aggregate value involved and distribution across various categories of cases. The Board or one of its Committees shall periodically review the unauthorised electronic payment transactions reported by customers or otherwise, as also the action taken thereon, the functioning of the grievance redressal mechanism and take appropriate measures to improve the systems and procedures.

## 18. Information system audit

18.1 Banks shall be guided by [RBI circulars DBS.CO.ITC.BC.No.6/31.02.008/2010-11 dated April 29, 2011](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=6366&Mode=0), [DBS.CO/CSITE/BC.11/33.01.001/2015-16 dated June 02, 2016](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=10435&Mode=0), [DCBS.CO.PCB.Cir.No.1/18.01.000/2018-19 dated October 19, 2018](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11397&Mode=0) (as applicable) and other relevant circulars on the subject, as amended from time to time.

18.2 Authorised non-bank PPI issuer shall submit a System Audit Report (SAR), including cyber security audit conducted by CERT-IN empaneled auditor, within two months of the close of its financial year to the respective Regional Office of DPSS, RBI. They shall also be guided by DPSS letter DPSS.CO.OD.No.1325/06.11.001/2019-20 dated January 10, 2020 (as amended from time to time) regarding System Audit of Payment Systems, as amended from time to time.

18.3 PPI issuer shall, at the minimum, put in place the following framework:

- Application Life Cycle Security: The source code audits shall be conducted by professionally competent personnel / service providers or have assurance from application providers / OEMs that the application is free from embedded malicious / fraudulent code.

- Security Operations Centre (SOC): Integration of system level (server), application level logs of mobile applications (PPIs) with SOC for centralised and co-ordinated monitoring and management of security related incidents.

- Anti-Phishing: Subscribe to anti-phishing / anti-rouge app services from external service providers for identifying and taking down phishing websites / rouge applications in the wake of increase of rogue mobile apps / phishing attacks.

- Risk-based Transaction Monitoring: Risk-based transaction monitoring or surveillance process shall be implemented as part of fraud risk management system.

- Vendor Risk Management: (i) Enter into an agreement with the service provider that amongst others provides for right of audit / inspection by the regulators of the country; (ii) RBI shall have access to all information resources (online / in person) that are consumed by PPI provider, to be made accessible to RBI officials when sought, though the infrastructure / enabling resources may not physically be located in the premises of PPI provider; (iii) Adhere to the relevant legal and regulatory requirements relating to geographical location of infrastructure and movement of data out of borders; (iv) Review the security processes and controls being followed by service providers regularly; (v) Service agreements of PPI issuer with provider shall include a security clause on disclosing the security breaches if any happening specific to issuer’s ICT infrastructure or process including not limited to software, application and data as part of Security incident Management standards, etc.

- Disaster Recovery (DR): Consider having DR facility to achieve the Recovery Time Objective (RTO) / Recovery Point Objective (RPO) for the PPI system to recover rapidly from cyber-attacks / other incidents and safely resume critical operations aligned with RTO while ensuring security of processes and data is protected.

## 19. Reporting requirements

PPI issuer shall submit the following reports as per prescribed templates and frequency in this MD:

- Net-worth Certificate ([Annex-2](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_2.pdf));

- Declaration and Undertaking by the Director ([Annex-3](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_3.pdf));

- PPI Statistics ([Annex-4](https://rbidocs.rbi.org.in/rdocs/content/docs/82MD27082021ANN_4.xlsx));

- Auditor Certificate on maintenance of balance in Escrow Account ([Annex-5](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_5.pdf)); and

- PPI Customer Grievance Report ([Annex-6](https://rbidocs.rbi.org.in/rdocs/content/pdfs/82MD27082021ANN_6.pdf)).

## 20. Consolidated and other provisions

- With issuance of these Directions, the instructions / guidelines issued by the RBI, contained in Table-1 of [Annex-1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12156#A_1) are consolidated.

- The instructions / guidelines issued by the RBI contained in Table-2 of [Annex-1](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12156#A_1) are partially consolidated to the extent they are applicable to issuance and operations of PPIs.

---

## Annex-1

## Table 1: List of Circulars consolidated in the MD

| Sr. No. | Circular No. | Date | Subject |
| --- | --- | --- | --- |
| 1. | [DPSS.CO.PD.No.1873 / 02.14.06/ 2008-09](https://rbi.org.in/scripts/NotificationUser.aspx?Id=4953&Mode=0) | 27.04.2009 | Policy Guidelines for issuance and operation of Prepaid payment Instruments in India |
| 2. | [DPSS.CO.PD.No.344/ 02.14.06/ 2009-10](https://rbi.org.in/scripts/NotificationUser.aspx?Id=5216&Mode=0) | 14.08.2009 | Policy Guidelines for issuance and operation of Prepaid payment Instruments in India |
| 3. | [DPSS.CO.No.1041/ 02.14.006/ 2010-2011](https://rbi.org.in/scripts/NotificationUser.aspx?Id=6078&Mode=0) | 04.11.2010 | Issuance and Operation of pre-paid payment Instruments in India (Reserve Bank) Directions - Additional guidelines |
| 4. | [DPSS. CO. AD. No. / 780/ 02.27.004 / 2010-11](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=6115&Mode=0) | 24.11.2010 | Issuance and Operation of Prepaid Payment Instruments |
| 5. | DPSS.CO.OSD. No. 1381/ 06.08.001/ 2010-2011 | 27.12.2010 | Collection of Statistics on prepaid instruments |
| 6. | DPSS.CO.OSD. No. 1445/ 06.12.001/ 2010-2011 | 27.12.2010 | Issuance and operation of Prepaid Payment Instruments in India – Auditor Certificate on the balances in Escrow account |
| 7. | [DPSS No. 2174 / 02.14.004 / 2010-2011](https://rbi.org.in/scripts/NotificationUser.aspx?Id=6304&Mode=0) | 23.03.2011 | Issuance and Operation of pre-paid payment instruments in India- Clarification |
| 8. | [DPSS.CO.No.2501/ 02.14.06/ 2010-11](https://rbi.org.in/scripts/NotificationUser.aspx?Id=6388&Mode=0) | 04.05.2011 | Policy Guidelines for issuance and operation of Prepaid payment Instruments in India |
| 9. | [DPSS.CO.PD.No.225/ 02.14.006/2011-12](https://rbi.org.in/scripts/NotificationUser.aspx?Id=6656&Mode=0) | 04.08.2011 | Policy Guidelines for issuance and operation of Prepaid payment Instruments in India |
| 10. | [DPSS.CO.PD. No. 2256 / 02.14.006/ 2011-12](https://rbi.org.in/scripts/NotificationUser.aspx?Id=7270&Mode=0) | 14.06.2012 | Policy Guidelines for issuance and operation of Prepaid payment Instruments in India |
| 11. | [DPSS.CO.PD.No.560/ 02.14.006/2012-13](https://rbi.org.in/scripts/NotificationUser.aspx?Id=7597&Mode=0) | 01.10.2012 | Policy Guidelines for issuance and operation of Prepaid payment Instruments in India - Amendments |
| 12. | [DPSS.CO.OSD.No.1604/ 06.06.005/2012- 13](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=7892&Mode=0) | 14.03.2013 | Collection of Information on Customer Grievances |
| 13. | [DPSS.CO.PD.No.563/ 02.14.003/2013-14](https://rbi.org.in/scripts/NotificationUser.aspx?Id=8382&Mode=0) | 05.09.2013 | Cash withdrawal at Point of Sale (POS) - Prepaid Payment Instruments issued by banks |
| 14. | [DPSS.CO.PD.No.2074/ 02.14.006/2013-14](https://rbi.org.in/scripts/NotificationUser.aspx?Id=8814&Mode=0) | 28.03.2014 | Issuance and Operation of Prepaid Payment Instruments in India – Consolidated Revised Policy Guidelines |
| 15. | [DPSS.CO.PD.No.2366/ 02.14.006/2013-14](https://rbi.org.in/scripts/NotificationUser.aspx?Id=8876&Mode=0) | 13.05.2014 | Issuance and Operation of Pre-paid Payment Instruments in India – Consolidated Revised Policy Guidelines |
| 16. | [DPSS.CO.PD.PPI.No.3/ 02.14.006/2014-15](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=8993&Mode=0) | 01.07.2014 | Master Circular – Policy Guidelines on Issuance and Operation of Pre-paid Payment Instruments in India |
| 17. | [DPSS.CO.PD.No.980/ 02.14.006/2014-15](https://rbi.org.in/scripts/NotificationUser.aspx?Id=9383&Mode=0) | 03.12.2014 | Issuance and operation of Prepaid payment instruments (PPIs) in India-Relaxations |
| 18. | [DPSS.CO.PD.PPI.No.2/ 02.14.006/2015-16](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=9872&Mode=0) | 01.07.2015 | Master Circular – Policy Guidelines on Issuance and Operation of Pre-paid Payment Instruments in India |
| 19. | [DPSS.CO.PD.No.58/ 02.14.006/2015-2016](https://rbi.org.in/Scripts/NotificationUser.aspx?Id=9935&Mode=0) | 09.07.2015 | Prepaid payment instrument (PPI) guidelines- Introduction of New Category of PPI for Mass Transit Systems (PPI-MTS) |
| 20. | [DPSS.CO.PD.PPI.No.01/ 02.14.006/2016-17](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=10510&Mode=0) | 01.07.2016 | Master Circular – Policy Guidelines on Issuance and Operation of Pre-paid Payment Instruments in India |
| 21. | [DPSS.CO.PD.No.1288/ 02.14.006/2016-17](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=10734&Mode=0) | 22.11.2016 | Special Measures to incentivise Electronic Payments – (i) Enhancement in Issuance Limits for PPIs in India (ii) Special measures for merchants |
| 22. | [DPSS.CO.PD.No.1610/ 02.14.006/2016-17](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=10799&Mode=0) | 27.12.2016 | Master Circular on Issuance and Operations of Prepaid Payment Instruments – Amendments to paragraph 7.9 |
| 23. | [DPSS.CO.PD.No.1669/ 02.14.006/2016-2017](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=10806&Mode=0) | 30.12.2016 | Special measures to incentivise Electronic Payments – Extension of time |
| 24. | [DPSS.CO.PD.No.1164/02.14.006/2017-18](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11142&Mode=0) | 11.10.2017 | Master Direction on Issuance and Operation of Prepaid Payment Instruments (Updated as on November 17, 2020) |
| 25. | [DPSS.CO.PD.No.808/02.14.006/2018-19](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11393&Mode=0) | 16.10.2018 | Prepaid Payment Instruments (PPIs) – Guidelines for Interoperability |
| 26. | [DPSS.CO.PD.No.1417/02.14.006/2018-19](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11446&Mode=0) | 04.01.2019 | Customer Protection – Limiting Liability of Customers in Unauthorised Electronic Payment Transactions in PPIs issued by Authorised Non-banks |
| 27. | [DPSS.CO.PD.No.499/02.14.006/2019-20](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11673&Mode=0) | 30.08.2019 | Amendment to Master Direction on Issuance and Operation of Prepaid Payment Instruments (PPIs) |
| 28. | [DPSS.CO.PD.No.1198/02.14.006/2019-20](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11766&Mode=0) | 24.12.2019 | Introduction of a new type of semi-closed PPI – PPIs upto ₹ 10,000/- with loading only from bank account |

## Table 2: List of Circulars partially consolidated (to the extent they are applicable to issuance and operation of PPIs) in the MD

| Sr. No. | Circular No. | Date | Subject |
| --- | --- | --- | --- |
| 1. | [DPSS.AD.No./ 1206/ 02.27.005/2009-2010](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=6183&Mode=0) | 07.12.2009 | System Audit of the Payment Systems operated under the PSS Act, 2007 |
| 2. | [DPSS.CO.OSD.No.1444 / 06.11.001/ 2010-2011](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=6177&Mode=0) | 27.12.2010 | Directions for submission of system audit reports from CISA qualified Auditor |
| 3. | [DPSS.CO.OSD. No.2374 / 06.11.001/ 2010-2011](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=6344&Mode=0) | 15.04.2011 | Submission of System Audit Reports |
| 4. | [DPSS.PD.CO.No. 622/ 02.27.019/2011-2012](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=6750&Mode=0) | 05.10.2011 | Domestic Money Transfer- Relaxations |
| 5. | [DPSS.CO.AD.No.1204/ 02.27.005/2014-15](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=9446&Mode=0) | 02.01.2015 | Brand/Name of products offered by authorised entities – Dissemination of Information |
| 6. | [DPSS.CO.AD.No.1344 / 02.27.005/2014-15](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=9490&Mode=0) | 16.01.2015 | Computation of Net-worth |
| 7. | [DPSS.CO.PD.No.660/02.14.008/2020-21](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11996&Mode=0) | 17.11.2020 | Maintenance of Escrow Account with a Scheduled Commercial Bank |
| 8. | [DPSS.CO.PD.No.S-99/ 02.14.006/2021-22](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12094&Mode=0) | 19.05.2021 | Prepaid Payment Instruments (PPIs) – (i) Mandating Interoperability; (ii) Increasing the Limit to ₹2 lakh for Full-KYC PPIs; and (iii) Permitting Cash Withdrawal from Full-KYC PPIs of Non-Bank PPI Issuer |
| 9. | [CO.DPSS.POLC.No.S-106/02-14-003/2021-22](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12095&Mode=0) | 21.05.2021 | Relaxation in timeline for compliance with various payment system requirements |

---

## Appendix

## List of Acronyms used

| Sr. No. | Acronym | Expansion |
| --- | --- | --- |
| 1 | 2FA | Two Factor Authentication |
| 2 | AFA | Additional Factor of Authentication |
| 3 | AML | Anti-Money Laundering |
| 4 | ATMs | Automated Teller Machines |
| 5 | BCs | Business Correspondents |
| 6 | CA | Chartered Accountant |
| 7 | CFT | Combating Financing of Terrorism |
| 8 | CGM | Chief General Manager |
| 9 | CNP | Card Not Present |
| 10 | CO | Central Office |
| 11 | CoA | Certificate of Authorisation |
| 12 | DEA Fund | Depositor Education and Awareness Fund |
| 13 | DPSS | Department of Payment and Settlement Systems |
| 14 | DR | Disaster Recovery |
| 15 | FAQs | Frequently Asked Questions |
| 16 | FDI | Foreign Direct Investment |
| 17 | FED | Foreign Exchange Department |
| 18 | FII | Foreign Institutional Investment |
| 19 | FIU-IND | Financial Intelligence Unit-India |
| 20 | FN | Fortnightly |
| 21 | FPI | Foreign Portfolio Investment |
| 22 | KYC | Know Your Customer |
| 23 | LB | Lowest Daily Outstanding Balance |
| 24 | LRS | Liberalised Remittances Scheme |
| 25 | MD | Master Directions |
| 26 | MD-PPIs | Master Directions on Prepaid Payment Instruments |
| 27 | MIS | Management Information System |
| 28 | MoA | Memorandum of Association |
| 29 | MTSS | Money Transfer Service Scheme |
| 30 | NETC | National Electronic Toll Collection |
| 31 | NPCI | National Payments Corporation of India |
| 32 | ODR | Online Dispute Resolution |
| 33 | OTP | One Time Password |
| 34 | OVD | Officially Valid Document |
| 35 | PMLA | Prevention of Money Laundering Act, 2002 |
| 36 | PoS | Point of Sale |
| 37 | PPI | Prepaid Payment Instrument |
| 38 | PPI-MD | Master Direction dated October 11, 2017 on Issuance and Operation of Prepaid Payment Instruments |
| 39 | PPI-MTS | PPIs for Mass Transit Systems |
| 40 | PSOs | Payment System Operators |
| 41 | PSP | Payment System Providers |
| 42 | PSS Act | Payment and Settlement Systems Act, 2007 |
| 43 | PSS Regulations | Payment and Settlement Systems Regulations, 2008 |
| 44 | RBI | Reserve Bank of India |
| 45 | RPO | Recovery Point Objective |
| 46 | RTO | Recovery Time Objective |
| 47 | SAR | System Audit Report |
| 48 | SOC | Security Operations Centre |
| 49 | STRs | Suspicious Transaction Reports |
| 50 | TAT | Turn Around Time |
| 51 | UPI | Unified Payments Interface |

---

[1]  Earlier, PPIs were classified under three types viz. (i) Closed System PPIs, (ii) Semi-closed System PPIs and (iii) Open System PPIs. Closed System PPIs are issued by an entity for facilitating the purchase of goods and services from that entity only and do not permit cash withdrawal. As these instruments cannot be used for payments or settlement for third party services, the issuance and operation of such instruments is not classified as payment systems requiring approval / authorisation by the RBI. Semi-closed System PPIs are used for purchase of goods and services, including financial services, remittance facilities, etc., at a group of clearly identified merchant locations / establishments which have a specific contract with the issuer (or contract through a payment aggregator / payment gateway) to accept the PPIs as payment instruments. These instruments do not permit cash withdrawal, irrespective of whether they are issued by banks or non-banks. Open System PPIs are issued by banks and used at any merchant for purchase of goods and services, including financial services, remittance facilities, etc. Banks issuing such PPIs shall also facilitate cash withdrawal at ATMs / Points of Sale (PoS) devices / Business Correspondents (BCs). This classification has since been modified.
